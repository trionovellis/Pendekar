/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface DirectorFilm {
  id: string;
  title: string;
  year: string;
  role: string;
  director: string;
  cast: string[];
  studio: string;
  awards?: string;
  synopsis: string;
  craftNotes: string;
  imdbUrl?: string;
  posterBg: string;
  posterImg: string;
  tag: string;
  category: 'action' | 'award' | 'iko' | 'all';
}

export const JOHN_RADEL_BIO = {
  name: 'John Radel, ACS',
  title: 'CEO • Producer • Cinematographer',
  accreditation: 'Australian Cinematographers Society (ACS)',
  awardsCount: '35+ Prestigious Industry Accolades',
  education: 'Budapest Cinematography Masterclasses under legends Vilmos Zsigmond ASC HSC (The Deer Hunter, Close Encounters) & László Kovács ASC HSC (Easy Rider)',
  profileImg: '/posters/john_radel_portrait.png',
  imdbUrl: 'https://www.imdb.com/name/nm1634700/',
  bioParagraphs: [
    'John Radel is an award-winning, ACS-accredited cinematographer and producer, celebrated for his visually stunning films and a career spanning over 35 prestigious industry accolades. Renowned for his ability to craft compelling visuals and captivating narratives, John seamlessly blends visionary artistic aesthetic with rigorous technical expertise.',
    'His journey began with a deep admiration for European and Asian cinema, which led him to Budapest to study under legendary cinematographers Vilmos Zsigmond ASC HSC (The Deer Hunter, Close Encounters of the Third Kind) and László Kovács ASC HSC (Easy Rider). Inspired by their mastery, John relocated to Asia, spending over two decades working across Indonesia, Singapore, Korea, China, the Philippines, Thailand, and Hong Kong.',
    'John has contributed to a diverse range of high-profile international blockbusters. He served as Line Producer on Michael Mann’s Blackhat starring Chris Hemsworth, co-produced Netflix’s action milestone The Night Comes for Us featuring Joe Taslim and Iko Uwais, and co-produced the acclaimed feature Monkey Man directed by and starring Dev Patel. As Director of Photography, he shot the American sci-fi drama After the Dark, Losmen Melati, and Buffalo Boys—Singapore’s official entry for the 91st Academy Awards for Best Foreign Language Film.',
    'Most recently, John served as Director of Photography on the sci-fi martial arts feature Skyline: Warpath, starring Iko Uwais and Scott Adkins, and the action-adventure film Alphas for XYZ Films, shot across South Africa and London.',
  ],
};

export const DIRECTOR_FILMS: DirectorFilm[] = [
  {
    id: 'monkey-man',
    title: 'Monkey Man',
    year: '2024',
    role: 'Co-Producer',
    director: 'Dev Patel',
    cast: ['Dev Patel', 'Sharlto Copley', 'Pitobash', 'Sobhita Dhulipala', 'Vipin Sharma'],
    studio: 'Universal Pictures • Monkeypaw Productions (Jordan Peele)',
    awards: 'SXSW Film Festival Audience Award Winner • Global Theatrical Box Office Hit',
    synopsis:
      'An anonymous young man unleashes a campaign of vengeance against the corrupt leaders who murdered his mother and systematically victimize the poor and powerless in fictionalized Yatana.',
    craftNotes:
      'Co-produced in close collaboration with Dev Patel and Jordan Peele’s Monkeypaw Productions, navigating complex international stunt choreography and gritty handheld kinetic realism.',
    imdbUrl: 'https://www.imdb.com/title/tt9214772/',
    posterBg: 'from-red-950 via-zinc-900 to-black',
    posterImg: '/posters/monkey-man.png',
    tag: 'Universal / Monkeypaw',
    category: 'action',
  },
  {
    id: 'skyline-warpath',
    title: 'Skyline: Warpath',
    year: '2025',
    role: 'Director of Photography',
    director: 'Liam O’Donnell',
    cast: ['Iko Uwais', 'Scott Adkins', 'Louis Mandylor', 'Randall Bacon', 'Yayan Ruhian'],
    studio: 'XYZ Films',
    awards: 'Anticipated Global Sci-Fi Martial Arts Franchise Installment',
    synopsis:
      'Set within the Skyline universe, Sua leads the human resistance against alien conquerors, teaming up with elite martial artists to unleash brutal close-quarters combat against extraterrestrial biomechanical armies.',
    craftNotes:
      'Captured with large-format anamorphic lenses, balancing complex sci-fi visual effects lighting with raw, bone-crunching martial arts stunt choreography featuring Iko Uwais and Scott Adkins.',
    imdbUrl: 'https://www.imdb.com/title/tt30953185/',
    posterBg: 'from-amber-950 via-stone-900 to-black',
    posterImg: '/posters/skyline-warpath.png',
    tag: 'Sci-Fi Martial Arts',
    category: 'iko',
  },
  {
    id: 'alphas',
    title: 'Alphas',
    year: '2025',
    role: 'Director of Photography',
    director: 'Liam O’Donnell',
    cast: ['International Stunt & Action Ensemble'],
    studio: 'XYZ Films (Filmed in South Africa & London)',
    awards: 'High-concept aquatic thriller',
    synopsis:
      'When an aggressive school of killer great white sharks threatens a coastal community, an environmentalist is tasked with training a pod of captive orcas to fight back in open waters.',
    craftNotes:
      'Shot across open marine environments and state-of-the-art water stages in South Africa and the UK, pioneering deep-water lighting techniques and rapid action underwater photography.',
    imdbUrl: 'https://www.imdb.com/name/nm1634700/',
    posterBg: 'from-cyan-950 via-slate-900 to-black',
    posterImg: '/posters/alphas.png',
    tag: 'Aquatic Action Thriller',
    category: 'action',
  },
  {
    id: 'dance-of-the-dragon',
    title: 'Dance of the Dragon',
    year: '2008',
    role: 'Director of Photography',
    director: 'Max Mannix & John Radel',
    cast: ['Jason Scott Lee', 'Fann Wong', 'Jang Hyuk'],
    studio: 'Easternlight Films',
    awards: 'Best Cinematography Award Winner • Multiple International Film Festival Honors',
    synopsis:
      'A young Korean martial artist journeys to Singapore to pursue ballroom dancing under an alluring mentor, leading to intense artistic and romantic rivalry with a former champion.',
    craftNotes:
      'Celebrated with the prestigious Best Cinematography Award for its poetic fusion of fluid ballroom camera movement and sharp martial arts precision lighting.',
    imdbUrl: 'https://www.imdb.com/title/tt1090698/',
    posterBg: 'from-amber-950 via-neutral-900 to-black',
    posterImg: '/posters/dance-of-the-dragon.png',
    tag: 'Best Cinematography Winner',
    category: 'award',
  },
  {
    id: 'after-the-dark',
    title: 'After the Dark (The Philosophers)',
    year: '2013',
    role: 'Director of Photography',
    director: 'John Huddles',
    cast: ['James D’Arcy', 'Sophie Lowe', 'Bonnie Wright', 'Daryl Sabara', 'Cinta Laura Kiehl'],
    studio: 'An Olive Branch Productions',
    awards: 'Sitges Film Festival Official Selection • Shot across Indonesian World Heritage Sites',
    synopsis:
      'At an international school in Jakarta, a brilliant philosophy teacher challenges his twenty graduating seniors to a mental nuclear apocalypse experiment to determine who deserves entry to a bunker.',
    craftNotes:
      'Showcases breathtaking widescreen cinematography shot on location at Mount Bromo, Prambanan Temple, and Belitung Island, creating surreal post-apocalyptic conceptual lighting.',
    imdbUrl: 'https://www.imdb.com/title/tt1928340/',
    posterBg: 'from-blue-950 via-slate-900 to-black',
    posterImg: '/posters/after-the-dark.png',
    tag: 'Psychological Sci-Fi',
    category: 'action',
  },
  {
    id: 'blackhat',
    title: 'Blackhat',
    year: '2015',
    role: 'Line Producer',
    director: 'Michael Mann',
    cast: ['Chris Hemsworth', 'Viola Davis', 'Tang Wei', 'Leehom Wang', 'Holt McCallany'],
    studio: 'Universal Pictures • Legendary Pictures',
    awards: 'Acclaimed collaboration with legendary director Michael Mann',
    synopsis:
      'A furloughed convicted computer genius and his American and Chinese partners race against time to intercept a ruthless cyber-terrorist syndicate orchestrating industrial disaster.',
    craftNotes:
      'Managed massive multinational physical production infrastructure across Jakarta, Hong Kong, Malaysia, and Los Angeles under Michael Mann’s exacting visual standards.',
    imdbUrl: 'https://www.imdb.com/title/tt2719848/',
    posterBg: 'from-yellow-950 via-zinc-900 to-black',
    posterImg: '/posters/blackhat.png',
    tag: 'Michael Mann / Universal',
    category: 'action',
  },
  {
    id: 'equals',
    title: 'Equals',
    year: '2015',
    role: 'International Production & Cinematography Team',
    director: 'Drake Doremus (Exec. Produced by Ridley Scott)',
    cast: ['Kristen Stewart', 'Nicholas Hoult', 'Guy Pearce', 'Jacki Weaver'],
    studio: 'Scott Free Productions • A24',
    awards: 'Venice International Film Festival (In Competition) • Toronto International Film Festival',
    synopsis:
      'In a sterile, emotionless future society where love is outlawed, two citizens diagnosed with Switched-On Syndrome find themselves irrevocably drawn to each other.',
    craftNotes:
      'Engineered minimalist architectural compositions and ultra-soft diffused color spectrums depicting emotional suppression and awakening.',
    imdbUrl: 'https://www.imdb.com/title/tt3289728/',
    posterBg: 'from-sky-950 via-zinc-900 to-black',
    posterImg: '/posters/equals.png',
    tag: 'Ridley Scott / A24',
    category: 'award',
  },
  {
    id: 'buffalo-boys',
    title: 'Buffalo Boys',
    year: '2018',
    role: 'Director of Photography',
    director: 'Mike Wiluan',
    cast: ['Ario Bayu', 'Mike Wiluan', 'Pevita Pearce', 'Yoshi Sudarso', 'Alex Abbad'],
    studio: 'Infinite Studios',
    awards: 'Singapore Official Submission for the 91st Academy Awards (Best Foreign Language Film)',
    synopsis:
      'Two brothers exiled to America return to 19th-century colonial Java to avenge their father’s death and liberate their people in an explosive Western martial arts showdown.',
    craftNotes:
      'Crafted the visual identity of the "Asian Western", combining sprawling tropical sunset vistas, dust-filled tavern shootouts, and traditional Indonesian weapon combat.',
    imdbUrl: 'https://www.imdb.com/title/tt7663242/',
    posterBg: 'from-orange-950 via-stone-900 to-black',
    posterImg: '/posters/buffalo-boys.png',
    tag: 'Academy Award Submission',
    category: 'award',
  },
  {
    id: 'operandi-gerhana',
    title: 'Operandi Gerhana (Operandi Grahana)',
    year: '2023',
    role: 'Director of Photography',
    director: 'Mike Wiluan',
    cast: ['Bront Palarae', 'Carmen Soo', 'Aaron Aziz', 'Farish Aziz'],
    studio: 'Netflix Original Series',
    awards: 'Asian Academy Creative Awards Winner • Best Cinematography',
    synopsis:
      'A retro neo-noir crime saga set in the steamy streets and corrupt underworld syndicates of 1970s Southeast Asia, where loyalty is constantly traded for blood.',
    craftNotes:
      'Honored with the Asian Academy Creative Award for Best Cinematography, utilizing vintage glass, deep shadow falloff, and neon-drenched atmospheric smoke.',
    imdbUrl: 'https://www.imdb.com/name/nm1634700/',
    posterBg: 'from-emerald-950 via-zinc-900 to-black',
    posterImg: '/posters/operandi-gerhana.png',
    tag: 'Asian Academy Winner',
    category: 'award',
  },
  {
    id: 'the-night-comes-for-us',
    title: 'The Night Comes for Us',
    year: '2018',
    role: 'Co-Producer',
    director: 'Timo Tjahjanto',
    cast: ['Joe Taslim', 'Iko Uwais', 'Julie Estelle', 'Zack Lee', 'Dian Sastrowardoyo'],
    studio: 'Netflix • XYZ Films',
    awards: 'Fantastic Fest Official Selection • Cult Martial Arts Masterpiece',
    synopsis:
      'An elite triad executioner spares a young girl during a massacre, inciting the full fury of his syndicate and a merciless showdown with his closest brother-in-arms.',
    craftNotes:
      'Spearheaded production logistics for what critics consider one of the most brutal and groundbreaking action films of modern cinema, reuniting Iko Uwais and Joe Taslim.',
    imdbUrl: 'https://www.imdb.com/title/tt6118306/',
    posterBg: 'from-rose-950 via-neutral-900 to-black',
    posterImg: '/posters/the-night-comes-for-us.png',
    tag: 'Iko Uwais & Joe Taslim',
    category: 'iko',
  },
  {
    id: 'headshot',
    title: 'Headshot',
    year: '2016',
    role: 'Co-Producer',
    director: 'The Mo Brothers',
    cast: ['Iko Uwais', 'Chelsea Islan', 'Sunny Pang', 'Julie Estelle'],
    studio: 'XYZ Films • Screenplay Infinite Films',
    awards: 'Toronto International Film Festival Official Selection (TIFF Vanguard)',
    synopsis:
      'An amnesiac fighter washed ashore awakens with mysterious bullet wounds, only to discover his forgotten past holds the key to a ruthless syndicate of trained child assassins.',
    craftNotes:
      'Collaborated on world-class Pencak Silat stunt logistics and high-intensity production environments across coastal and urban Indonesia.',
    imdbUrl: 'https://www.imdb.com/title/tt5147214/',
    posterBg: 'from-amber-950 via-zinc-900 to-black',
    posterImg: '/posters/headshot.jpg',
    tag: 'TIFF Vanguard / Iko Uwais',
    category: 'iko',
  },
];
