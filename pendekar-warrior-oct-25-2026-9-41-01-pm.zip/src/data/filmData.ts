/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Character {
  id: string;
  name: string;
  role: string;
  tagline: string;
  img: string;
  desc: string;
  motivation: string;
  conflict: string;
  style: string;
  archetype: string;
}

export interface FilmLocation {
  id: string;
  number: string;
  name: string;
  tagline: string;
  region: string;
  img: string;
  description: string;
  atmosphere: string;
  significance: string;
}

export interface ProductionStill {
  id: string;
  title: string;
  caption: string;
  location: string;
  img: string;
  category: 'Character' | 'Location' | 'Action' | 'Story';
}

export interface ScreenplayChapter {
  id: string;
  chapter: string;
  title: string;
  quote: string;
  synopsis: string;
  location: string;
}

export const CHARACTERS: Character[] = [
  {
    id: 'jaya',
    name: 'Abah Jaya',
    role: 'The Reluctant Protector',
    tagline: 'Seven years behind bars. A lifetime of instincts to restrain.',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAm4_p-rCBQVSo58rxOlY62UjBWr1CADu33V_Gaver3VZphcVm6rDK-sChKEQ1kgLtRCxgfjydz0H9B-WYn4rPQAnXmcallyp4ELbt-1UmjaJFeFzoyJqdhC0qfvpw4qjQKpWNzmiUSpj2mI-avtOC9muyxmmWUFlLV1AE782CI8FDaCH6Q5etb0L8yFfIB-Jsc9D0oSiVqT8HdAPydkjcGvwfkFVwEEa9tvPmWQrbVDeOLaX7qxHHE4A',
    desc: 'A former fighter who spent seven years in Cipinang Prison, Jaya wants nothing more than a quiet life away from the violence that ruined him. When his nephew Rama is left alone after a family tragedy, Jaya steps in to protect the boy, only to realize that staying out of the fight may be impossible.',
    motivation: 'Redemption and breaking the generational cycle of bloodshed.',
    conflict: 'Confronting the lethal instincts he swore never to unleash again.',
    style: 'Traditional Harimau Pencak Silat • Ground sweeps, leverage, defensive deflection',
    archetype: 'The Reformed Master',
  },
  {
    id: 'rama',
    name: 'Rama',
    role: 'The Young Fighter',
    tagline: 'Raw grief searching for justice in an unforgiving city.',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAEQ3yNWaYQqrRWbnBeY_tKjQC6Vy0qcqT3pW1-nfPMcpHTcKvpQvdJzSp45n92lW-guZ9PTKSWz3iia-Qh7pYOCodMuC5xWGMMwek7JWTPV0TW-xCoKCOGIUgRQKQ-ysemS406LIW_G2gNl1ER9djHv9mlPsG5A_FlUiXmV31uj2nVXqOUor17TRyNbc7N99X1-x0JcUVu6F0smFU6mJ6siT1WAcLfAGKW8TA9ahpcruB6QEyzA7we0Q',
    desc: "Jaya's nephew, raw, grieving, and full of unfocused anger. Facing the sudden loss of his family, Rama is easily drawn into street brawls and dangerous choices, searching for respect and justice in a world that offers neither.",
    motivation: 'Vindicating his loss and finding purpose after family tragedy.',
    conflict: 'Choosing between blind vengeance and disciplined restraint.',
    style: 'Street Brawling blended with nascent Silat footwork',
    archetype: 'The Impulsive Protege',
  },
  {
    id: 'ayu',
    name: 'Ayu',
    role: 'The Streetwise Survivor',
    tagline: 'Operating on intuition across the night markets.',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCkb8q2PnjqkdIfqnzl5Pz6Vu9dFfTiszsY9b8uh3hJmb0TzGGVAGzQdnAIKtYU9lidlp5N2jTAqYb9o8rKOnuRg_1lUU9nge1TUUzOoOC5EywsxafJzQY_zeg-yqJuhRYIXMiZyGFwTwKa3i7Qc80BHOBWX3CiW1ClakOLXAsnuivXQyNdO8iOqonSnZJVyRIMzLJDzQ0SH4WQjBy0vbUwfIaRz9-Kg_87tB9BXPK4',
    desc: 'Sharp, observant, and independent, Ayu navigates the backstreets and night markets with a survivor’s instincts. She understands how quickly small disputes escalate into life-and-death encounters and acts as an alert ally.',
    motivation: 'Independence and navigating the unforgiving urban margins.',
    conflict: 'Deciding who to trust when underworld syndicates close in.',
    style: 'Agile evasive tactics, urban improvisation',
    archetype: 'The Urban Scout',
  },
  {
    id: 'dewi',
    name: 'Dewi',
    role: 'A Figure in the Underworld',
    tagline: 'Where business, corruption, and old debts converge.',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAvTMDHzyfYDmIiExz4DJAGKUJffrq3mVDEHF-mtIhUgLfmDBqol8Kp7MeKBvm8mPd-h8TF4LsY2Zi28Plal7piyZ6ecwKLw-i5TyC3loEl8a3Z22CPpRC-NHySDQqvpeKZaFnZCMZ0sT5S-pfoIMm1Nei90wKnBXaYXaqThsaxPyBa74czLXx-9IMW8s3KQtmzimMcoU_QZaWaluEG-WEMJeXSKpWydwivfAxo19-E',
    desc: 'Poised, dangerous, and deeply entrenched in the criminal networks that hold power in Jakarta’s shadows. Dewi operates where business, corruption, and violence intersect, holding ties to Jaya’s unresolved past.',
    motivation: 'Power and territorial control across the city’s lucrative syndicates.',
    conflict: 'Balancing old alliances with cold calculation.',
    style: 'Strategic orchestrator • Armed security entourage',
    archetype: 'The Syndicate Matriarch',
  },
  {
    id: 'kazu',
    name: 'Kazu',
    role: 'The Force Behind the Threat',
    tagline: 'Cold precision with no tolerance for disruption.',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD_9siMpd2vPCT5MatCLoZmlOPODj2ObHPGAAWok5RyqtbYVhgr0ueYOjFVtgaIhkln11lsEMoaQERU9YpkEjRCQtivSBsWdaNrgqW-Yw1RBRcQVfhCsBOdkWh8pCN9GQtxci2A9Q4-6_Mm7m7DEBbAB9uBBbqy9waltHFEPve9IVthQ2G2qlpA8ERGutyltRumiPuiXExB-jPOEzL8_sr74DZNjsxiJgDnW9H_DHbDOPnjVvMmjlqxTA',
    desc: 'A ruthless and controlled presence representing external criminal interests operating in Jakarta. Unforgiving and calculating, he views people solely as assets or obstacles to be eliminated.',
    motivation: 'Uncompromising expansion and enforcement of criminal authority.',
    conflict: 'Crushing anyone who disrupts his syndicate’s operations.',
    style: 'Lethal modern combat, ruthless bladed disarmament',
    archetype: 'The Syndicate Enforcer',
  },
];

export const LOCATIONS: FilmLocation[] = [
  {
    id: 'cipinang',
    number: '01',
    name: 'Cipinang Prison',
    tagline: 'Crucible of Silence',
    region: 'East Jakarta',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDq9dPdRWqgk22TFTgmKSpfKb8XyjOmQzm9n--PRn_ciLqNBBrI9UVsY9UupIkT1ZceGaMX15WqoSU-nDBTbd8l-c0eR4_fi56fbiVf630iKOtqILP4O2tOF790b0A1sVFRdgD3JgG2EyXCDK8sISzNAo6m-ZD6-V0FrwT_QsKhrFgf5_5ZCqV40yD7hTUcCW9_kKBiOCB1UccMO0jGmchEzuLoI2p8XpzD7XiwJqik',
    description: 'Seven years behind bars have shaped Jaya’s silence, discipline, and troubled past. A stark concrete crucible of survival.',
    atmosphere: 'Harsh industrial halogen, damp corridors, echoing metallic gates',
    significance: "Where Jaya buried his rage and committed to never striking first again.",
  },
  {
    id: 'garage',
    number: '02',
    name: "Jakarta's Backstreets",
    tagline: 'An Unlikely Sanctuary',
    region: 'Outskirts of Jakarta',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDJnn8EsvvleAEnD8gW4ELiISPxt-9WbW9Nb6tiU85ORsFotrn8d33y7SiUU-ahcYkXiXOvEGpulOKmJOceSmSUapvT10_tsiZN0QhXeDtPDTS3dmXKXXDh4tQSuD4YtaVW_d1M7t4ObIVyXhh_Umof9KJlc8Ib0ynuyQwiYwSf27b2nhwLd4O9czeoz72BcrZ7-h8hB4qOZc9PbiJlL-pr-NGow1HTpmzuT6c4MIcVWNcqaHM7EG_BBQ',
    description: 'An old auto workshop becomes an unlikely refuge—and the starting point of a fragile new life for Jaya and Rama amidst the urban sprawl.',
    atmosphere: 'Neon reflections on rain puddles, motor oil smell, rattling tin roofs',
    significance: 'Where Rama trains on the worn leather bag and Jaya teaches restraint.',
  },
  {
    id: 'sembungan',
    number: '03',
    name: 'Sembungan Village',
    tagline: 'Rural Heartland & Ancestral Roots',
    region: 'Dieng Highlands, Central Java',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuATCK-0JrIszpKJPf0nLJEQ8UdVotrc6xZLeARyxJoaqc85DBh__rGk74wr1QZvOAU0wtcG1DAiAiaxMKL6VFweF9MptLV7hCbshxTUTXAUFvHd0VUrIjB82K1I8aFBwSXN4QNNznmYWMnGad-RWk6obHoyMLOTHBve2jAeGPsDjlcnCr3SBYWH42UkJcrI4w8JFnHgPHqnxankepCp08WWwcT_4vknJDulFM0HCwJipvQYEOJF16AQEg',
    description: 'A mountain village where family grief changes Jaya’s path and brings him face to face with a responsibility he cannot ignore.',
    atmosphere: 'Misty volcanic peaks, terraced agricultural hills, somber ritual chants',
    significance: 'The funeral ceremony that binds Rama and Jaya in mutual guardianship.',
  },
];

export const GALLERY_ITEMS: ProductionStill[] = [
  {
    id: 'still-1',
    title: 'Cipinang Prison Gates',
    caption: 'Corridor inside Cipinang Prison, marking the starting point of Jaya’s release.',
    location: 'East Jakarta',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDq9dPdRWqgk22TFTgmKSpfKb8XyjOmQzm9n--PRn_ciLqNBBrI9UVsY9UupIkT1ZceGaMX15WqoSU-nDBTbd8l-c0eR4_fi56fbiVf630iKOtqILP4O2tOF790b0A1sVFRdgD3JgG2EyXCDK8sISzNAo6m-ZD6-V0FrwT_QsKhrFgf5_5ZCqV40yD7hTUcCW9_kKBiOCB1UccMO0jGmchEzuLoI2p8XpzD7XiwJqik',
    category: 'Location',
  },
  {
    id: 'still-2',
    title: 'Arrival by Rural Bus',
    caption: 'Jaya disembarking onto the highway bordering the agricultural outskirts.',
    location: 'Central Java Border',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC_4B_7YnoVtzF4pktq9QAukyHJUc_10FG3jehz3KKbqlfpA1mx_35HH_1gkA_vZn9XIL7nGB9aR6PuWDBMeYjnMOqfYdULcGPUpk8CiqJPrFn8kQLqOHHxt1ywYmlH0KPb_uOvUQVaKexnCBLHAHJwlEMOrn2rDUm2tPCUmwy97JzLm4AIGB-mtQVAqhbBVf-sDfkvRxs3yKpaK86sX7ZfaIWLmy09SyRjwylb1--6SqMg18J4vD24xA',
    category: 'Story',
  },
  {
    id: 'still-3',
    title: 'Crossing the Paddy Fields',
    caption: 'Walking the boundary trails towards a quiet life and ancestral ground.',
    location: 'Central Java',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAelHRPlEUvnovMfV26h9LuBdH5twwN1Cz3tyncpsKS0YPa1kOofpAoqmzNzNQW_AoPfzpn2o0D778bE9zMxW-yPP_wPD3kJTg0x_iyM8Ve-_tADeb7Ou8gU125dCMbSYhTwSNbJltuZ30oD1hNymgkvEpyiuRn9Qf6YeAK3FrNzPKPiBB58AFPvcj-Tbg-ihPrfq95OmlPPhSoYacHCfhOrl4MSQ1re0LNIrgMxZX4cSD3pysgyuIOug',
    category: 'Location',
  },
  {
    id: 'still-4',
    title: 'Garage Sanctuary',
    caption: 'Rama training by the bag at dusk while Jaya looks on from the porch.',
    location: 'Jakarta Outskirts',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDJnn8EsvvleAEnD8gW4ELiISPxt-9WbW9Nb6tiU85ORsFotrn8d33y7SiUU-ahcYkXiXOvEGpulOKmJOceSmSUapvT10_tsiZN0QhXeDtPDTS3dmXKXXDh4tQSuD4YtaVW_d1M7t4ObIVyXhh_Umof9KJlc8Ib0ynuyQwiYwSf27b2nhwLd4O9czeoz72BcrZ7-h8hB4qOZc9PbiJlL-pr-NGow1HTpmzuT6c4MIcVWNcqaHM7EG_BBQ',
    category: 'Character',
  },
  {
    id: 'still-5',
    title: 'Silat Compound Gathering',
    caption: 'Martial arts students gathered in circle practice at sundown.',
    location: 'Central Java',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDbdVqbWmey-Trozry9qX3Sb4Y5YFeWyt4lJu-IrQp5IXABcQH-tRMZ3H6EN8HKbq2PFgO22rFq36iZvzLYJDc51e-Jz8ZtA3dfuRHo-2I-oGu9D0OpI_4v0IjJjjWjwoSPVlYEj20RoTMrUIs0oMEDVxflJf7bz88KYDaMeUyK3-4lVBycoMw9ZlpNXtYmiNSm1gJYHZrNrdjc9em8m_aNOKaBmu8hVCBxthf_z0qGw24tUgx2wib9HA',
    category: 'Action',
  },
  {
    id: 'still-6',
    title: 'Highland Funeral Ceremony',
    caption: 'The family burial ceremony in Sembungan Village that unites Jaya and Rama.',
    location: 'Dieng Highlands',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuATCK-0JrIszpKJPf0nLJEQ8UdVotrc6xZLeARyxJoaqc85DBh__rGk74wr1QZvOAU0wtcG1DAiAiaxMKL6VFweF9MptLV7hCbshxTUTXAUFvHd0VUrIjB82K1I8aFBwSXN4QNNznmYWMnGad-RWk6obHoyMLOTHBve2jAeGPsDjlcnCr3SBYWH42UkJcrI4w8JFnHgPHqnxankepCp08WWwcT_4vknJDulFM0HCwJipvQYEOJF16AQEg',
    category: 'Story',
  },
  {
    id: 'still-7',
    title: 'Grief and Legacy',
    caption: 'Rama and Jaya facing the weight of the family loss together.',
    location: 'Central Java',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDY7s9pCSHSUMp__fuJcVLkCnwFiEgvu0kG8fV93F4XP2hFgIF1Jm9_6P1hMW8f_RW7Z-Xe3O7kwl3CChkziO_i6NGTh24Du53TT_BG1AR2OQVtA94Jn3hNleEjSEczneLUvDwagFF7oLBDdHVjsZ3L8DtOnJXGLpX8eLj60S1gcuygHGn_8c2XGSZfYGHa3eIgfSQgaGClvzh1E5i4sWTvHXehPlJblMAZmEbLbzRS410Eze386p-4lw',
    category: 'Character',
  },
  {
    id: 'still-8',
    title: 'Jakarta Night Alleys',
    caption: 'Jaya facing down impending conflict in the rain-soaked alleys.',
    location: 'Central Jakarta',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCD5NuCBMMe1JTjomcVrMqo6YXHL6E4FRUm4J2jsW9yG88eXJyD_NZus6YLCycQiJvJg9m7b_97Q1zkSvEvR3mVG1QJdizd-M9N5OW5evYBXG7nlO1od37ykHPLMDwPxroyJPVpTfXBtK_okeqxU063zrvocudHYBuJ399t4I4kmbFu1pUOYCELccxMXGvQ4MvzgoiiTEKLCSS_kIa7L_6vXsRWAZVsqRh7YqD4X3PqXFjUXM6BqtTZfA',
    category: 'Action',
  },
];

export const CHAPTERS: ScreenplayChapter[] = [
  {
    id: 'ch-1',
    chapter: '01',
    title: 'The Release',
    quote: 'Seven years behind iron gates teaches a man either total obedience or complete restraint.',
    synopsis: 'Abah Jaya walks through Cipinang Prison gates into the blinding Jakarta midday sun. In his pocket sits a single crumpled photo. His goal is simple: disappear into the city’s industrial periphery, repair rusted engines, and never raise his hands in anger again.',
    location: 'Cipinang, East Jakarta',
  },
  {
    id: 'ch-2',
    chapter: '02',
    title: 'The Sembungan Tragedy',
    quote: 'Blood calls a warrior back home, even when there is nothing left to save but a child.',
    synopsis: 'A telegram shatters the quiet. Jaya travels by rickety bus through terraced hills to Sembungan Village in Central Java. His brother is dead, leaving behind Rama, a teenage nephew whose rage burns unchecked.',
    location: 'Dieng Highlands, Central Java',
  },
  {
    id: 'ch-3',
    chapter: '03',
    title: 'The Garage Refuge',
    quote: 'True martial discipline is not teaching a boy how to hit, but when to walk away.',
    synopsis: 'Jaya brings Rama back to his workshop in Jakarta. By night, Rama sneaks out toward underground fight rings to avenge his father’s honor. Jaya realizes that guarding Rama requires teaching him the deadly discipline of Pencak Silat.',
    location: 'Jakarta Outskirts',
  },
  {
    id: 'ch-4',
    chapter: '04',
    title: 'Shadows of the Syndicate',
    quote: 'When the city claims a debt, it charges interest in blood.',
    synopsis: 'Dewi and Kazu’s enforcers tighten their perimeter. Rama unwittingly stumbles across an extortion ring, placing their garage directly in the crosshairs. Jaya must step between the syndicate and his nephew.',
    location: 'Glodok & Kota Tua, Jakarta',
  },
  {
    id: 'ch-5',
    chapter: '05',
    title: 'The Final Consequence',
    quote: 'The hardest fight is the one within.',
    synopsis: 'A brutal, close-quarters confrontation in the rain-drenched shipping alleys of North Jakarta. Jaya is pushed to the ultimate precipice: finish the enemy with the lethal strike he perfected in his youth, or demonstrate to Rama the sacred power of mercy.',
    location: 'Tanjung Priok, North Jakarta',
  },
];
