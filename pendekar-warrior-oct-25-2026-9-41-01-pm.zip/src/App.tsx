/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Play,
  ArrowDown,
  Lock,
  Shield,
  Maximize2,
  ExternalLink,
  MapPin,
  Film,
  Building2,
  Ticket,
} from 'lucide-react';
import { Navigation } from './components/Navigation';
import { CustomCursor } from './components/CustomCursor';
import { ScrollProgress } from './components/ScrollProgress';
import { LazyImage } from './components/LazyImage';
import { InteractiveButton } from './components/InteractiveButton';
import { CharacterDossier } from './components/CharacterDossier';
import { DirectorSection } from './components/DirectorSection';
import { ChapterTimeline } from './components/ChapterTimeline';
import { TrailerModal } from './components/TrailerModal';
import { GalleryModal } from './components/GalleryModal';
import { RSVPScreeningModal } from './components/RSVPScreeningModal';
import { OfflineSyncHub } from './components/OfflineSyncHub';
import { LOCATIONS, GALLERY_ITEMS, ProductionStill } from './data/filmData';
import { triggerHaptic } from './utils/haptics';

export default function App() {
  const [trailerOpen, setTrailerOpen] = useState(false);
  const [rsvpOpen, setRsvpOpen] = useState(false);
  const [selectedStill, setSelectedStill] = useState<ProductionStill | null>(null);

  return (
    <div className="bg-[#080B10] text-[#F3F0E8] font-['Be_Vietnam_Pro'] antialiased selection:bg-[#D4AF57] selection:text-[#080B10] min-h-screen">
      {/* ThoughtLab Smooth Scroll Progress & Custom Cursor */}
      <ScrollProgress />
      <CustomCursor />

      {/* Persistent Offline State Synchronization Hub */}
      <OfflineSyncHub />

      {/* Floating Top Navigation */}
      <Navigation
        onOpenTrailer={() => setTrailerOpen(true)}
        onOpenRSVP={() => setRsvpOpen(true)}
      />

      <main>
        {/* ======================================================== */}
        {/* SECTION B: CINEMATIC HERO                                */}
        {/* ======================================================== */}
        <section className="relative min-h-[92vh] lg:min-h-screen flex items-center pt-24 pb-16 overflow-hidden">
          {/* Background Film Still with Cinematic Depth */}
          <div className="absolute inset-0 z-0">
            <LazyImage
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuCD5NuCBMMe1JTjomcVrMqo6YXHL6E4FRUm4J2jsW9yG88eXJyD_NZus6YLCycQiJvJg9m7b_97Q1zkSvEvR3mVG1QJdizd-M9N5OW5evYBXG7nlO1od37ykHPLMDwPxroyJPVpTfXBtK_okeqxU063zrvocudHYBuJ399t4I4kmbFu1pUOYCELccxMXGvQ4MvzgoiiTEKLCSS_kIa7L_6vXsRWAZVsqRh7YqD4X3PqXFjUXM6BqtTZfA"
              alt="Cinematic film still showing weathered Jaya in a rain-soaked Jakarta alleyway"
              aspectRatioClass="h-full w-full"
              containerClassName="h-full w-full"
              className="object-cover object-[70%_center] lg:object-right brightness-[0.72] contrast-125"
              zoomOnHover={false}
            />
            {/* Atmospheric Shadows and Gradients */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#080B10] via-[#080B10]/60 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#080B10] via-[#080B10]/85 to-transparent lg:w-3/4" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_45%,rgba(17,22,32,0.65),transparent_70%)]" />
          </div>

          {/* Hero Content */}
          <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 w-full">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="max-w-2xl lg:max-w-3xl flex flex-col items-start"
            >
              {/* Eyebrow */}
              <div className="inline-flex items-center gap-3 mb-4">
                <span className="h-px w-8 bg-[#D4AF57]/80" />
                <span className="font-['Cinzel'] text-xs md:text-sm uppercase tracking-[0.3em] text-[#F0D995] font-semibold">
                  An Indonesian Action Thriller
                </span>
              </div>

              {/* Main Title Reveal (ThoughtLab Kinetic Style) */}
              <div className="flex flex-col items-start my-2">
                <span className="font-['Cinzel'] text-lg sm:text-2xl lg:text-3xl font-extrabold tracking-[0.38em] text-[#c0c5cc] uppercase block mb-1 drop-shadow-[0_2px_12px_rgba(0,0,0,0.8)]">
                  IKO UWAIS
                </span>
                <h1
                  className="font-['Cinzel'] text-5xl sm:text-7xl lg:text-9xl font-black tracking-[0.08em] uppercase text-transparent bg-clip-text bg-gradient-to-b from-[#e2e5eb] via-[#9ba2ad] to-[#5a606d] leading-[0.95] drop-shadow-[0_12px_35px_rgba(0,0,0,0.95)] select-none"
                  style={{
                    textShadow:
                      '2px 2px 0px #2a2e38, 4px 4px 0px #181c24, 6px 6px 0px #0b0e14, 0 16px 30px rgba(0,0,0,0.9)',
                  }}
                >
                  WARRIOR
                </h1>
                <span className="font-['Cinzel'] text-base sm:text-xl lg:text-2xl font-bold tracking-[0.35em] text-[#9ba2ad] uppercase block mt-2">
                  (PENDEKAR)
                </span>
              </div>

              {/* Tagline */}
              <p className="font-['Cinzel'] text-base sm:text-xl text-[#D4AF57] tracking-[0.24em] uppercase font-bold mt-4">
                The hardest fight is the one within.
              </p>

              {/* Supporting synopsis */}
              <p className="font-['Be_Vietnam_Pro'] text-sm sm:text-base text-[#9DA6B5] font-normal leading-relaxed mt-5 max-w-xl">
                After seven years in prison, Jaya is given a chance to rebuild his life. But when the past returns, protecting the family he has left may demand the one thing he has struggled to control: his own violence.
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap items-center gap-4 mt-8">
                <InteractiveButton
                  variant="gold"
                  hapticType="medium"
                  cursorLabel="play"
                  onClick={() => setTrailerOpen(true)}
                  className="px-8 py-3.5 text-xs sm:text-sm font-bold tracking-[0.2em]"
                >
                  <Play className="w-4 h-4 fill-current mr-2" />
                  <span>Watch the Trailer</span>
                </InteractiveButton>

                <InteractiveButton
                  variant="glass"
                  hapticType="light"
                  onClick={() => setRsvpOpen(true)}
                  className="px-7 py-3.5 text-xs sm:text-sm"
                >
                  <Ticket className="w-4 h-4 text-[#D4AF57] mr-2" />
                  <span>VIP Screener RSVP</span>
                </InteractiveButton>

                {/* Film IMDb Link */}
                <a
                  href="https://www.imdb.com/title/tt39331600/?ref_=ext_shr_lnk"
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => triggerHaptic('light')}
                  className="inline-flex items-center gap-1.5 px-4 py-3 rounded-xs bg-[#f5c518] hover:bg-[#e2b616] text-[#000000] font-sans font-black text-xs uppercase tracking-wider transition-all duration-200 shadow-md hover:scale-105"
                  title="View Pendekar Warrior on IMDb"
                >
                  <span>IMDb</span>
                  <ExternalLink className="w-3.5 h-3.5 stroke-[2.5]" />
                </a>
              </div>

              {/* Genre Metadata Strip */}
              <div className="mt-14 pt-6 border-t border-white/10 w-full flex flex-wrap items-center gap-y-2 gap-x-5 text-[11px] sm:text-xs uppercase tracking-[0.22em] text-[#9DA6B5] font-['Cinzel']">
                <span className="text-[#F3F0E8]">Action</span>
                <span className="text-[#D4AF57]">·</span>
                <span className="text-[#F3F0E8]">Martial Arts</span>
                <span className="text-[#D4AF57]">·</span>
                <span className="text-[#F3F0E8]">Crime Thriller</span>
                <span className="text-[#D4AF57]">·</span>
                <span className="text-[#F3F0E8]">Family Drama</span>
                <span className="text-[#D4AF57]">·</span>
                <span className="text-[#F0D995] font-semibold">Filmed at IMS (Iskandar Malaysia Studios)</span>
              </div>
            </motion.div>
          </div>
        </section>

        {/* ======================================================== */}
        {/* SECTION C: THE FILM / STORY INTRODUCTION                 */}
        {/* ======================================================== */}
        <section className="relative py-24 px-6 md:px-10 bg-[#111620]/40 border-t border-[#1F2633]" id="film">
          <div className="max-w-7xl mx-auto">
            {/* Header */}
            <div className="max-w-3xl mb-14" id="story">
              <span className="font-['Cinzel'] text-xs uppercase tracking-[0.28em] text-[#D4AF57] font-bold block mb-2">
                The Film
              </span>
              <h2 className="font-['Cinzel'] text-2xl sm:text-4xl text-[#F3F0E8] uppercase tracking-wider font-bold">
                A Past That Never Stays Buried
              </h2>
              <p className="font-['Be_Vietnam_Pro'] text-sm sm:text-base text-[#F0D995]/90 font-light italic mt-2">
                Some battles follow a man long after the fighting ends.
              </p>
            </div>

            {/* Two Column Layout: Media Preview + Three-paragraph Synopsis */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
              {/* Left: Image Preview Card with Interactive Play Trigger */}
              <div className="lg:col-span-6 relative group rounded-xs overflow-hidden border border-white/10 shadow-[0_12px_40px_rgba(0,0,0,0.8)]">
                <div
                  data-cursor="play"
                  onClick={() => {
                    triggerHaptic('medium');
                    setTrailerOpen(true);
                  }}
                  className="relative aspect-[16/10] overflow-hidden bg-[#080B10] cursor-pointer"
                >
                  <LazyImage
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuC_4B_7YnoVtzF4pktq9QAukyHJUc_10FG3jehz3KKbqlfpA1mx_35HH_1gkA_vZn9XIL7nGB9aR6PuWDBMeYjnMOqfYdULcGPUpk8CiqJPrFn8kQLqOHHxt1ywYmlH0KPb_uOvUQVaKexnCBLHAHJwlEMOrn2rDUm2tPCUmwy97JzLm4AIGB-mtQVAqhbBVf-sDfkvRxs3yKpaK86sX7ZfaIWLmy09SyRjwylb1--6SqMg18J4vD24xA"
                    alt="Jaya stepping off a rural bus in the outskirts"
                    aspectRatioClass="aspect-[16/10]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#080B10] via-[#080B10]/30 to-transparent" />

                  {/* Location Tag */}
                  <div className="absolute top-4 left-4 px-3 py-1 bg-[#080B10]/85 backdrop-blur-md border border-white/10 text-[10px] font-['Cinzel'] uppercase tracking-[0.2em] text-[#F0D995]">
                    Jakarta, Indonesia
                  </div>

                  {/* Central Play Trigger */}
                  <motion.div
                    whileHover={{ scale: 1.15 }}
                    whileTap={{ scale: 0.95 }}
                    className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-[#080B10]/85 border border-[#D4AF57]/70 text-[#D4AF57] flex items-center justify-center shadow-[0_0_25px_rgba(212,175,87,0.3)]"
                  >
                    <Play className="w-7 h-7 fill-current ml-0.5" />
                  </motion.div>
                </div>

                <div className="p-4 bg-[#252B35]/60 border-t border-white/5 flex flex-wrap items-center justify-between text-xs font-['Cinzel'] tracking-wider text-[#9DA6B5]">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[#F0D995] uppercase">Status: In Development</span>
                    <span className="text-white/20">·</span>
                    <a
                      href="https://asiamediaalliancegroup.com/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[#D4AF57] hover:text-[#F0D995] uppercase transition-colors font-semibold"
                    >
                      Asia Media Alliance Group <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                  <span className="text-[#F0D995]/90 font-semibold">Filmed at IMS (Iskandar Malaysia Studios)</span>
                </div>
              </div>

              {/* Right: 3-Paragraph Screenplay Synopsis */}
              <div className="lg:col-span-6 flex flex-col gap-5 text-sm sm:text-base text-[#9DA6B5] font-['Be_Vietnam_Pro'] leading-relaxed">
                <p>
                  Abah Jaya emerges from Cipinang Prison after seven years behind bars, carrying little more than a photograph, painful memories, and the hope of starting over. Seeking a quiet life on the outskirts of Jakarta, he settles into an old garage and tries to keep his past buried.
                </p>
                <p>
                  But when tragedy strikes his family, Jaya returns to Central Java and discovers that his young nephew, Rama, needs more than a place to stay. He needs someone who can show him a different way to survive.
                </p>
                <p>
                  As the two begin an uneasy life together, the violence Jaya once tried to leave behind closes in again. With dangerous forces connected to his past threatening those around him, Jaya must confront the man he used to be—and decide whether he can protect the next generation without becoming a killer once more.
                </p>
                <div className="pt-4 flex items-center gap-6 border-t border-white/10 text-xs font-['Cinzel'] uppercase tracking-widest text-[#F0D995]">
                  <span className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF57]" />
                    Grounded Realism
                  </span>
                  <span className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF57]" />
                    Authentic Pencak Silat
                  </span>
                </div>
              </div>
            </div>

            {/* ThoughtLab Interactive Screenplay Chapter Timeline */}
            <ChapterTimeline />
          </div>
        </section>

        {/* ======================================================== */}
        {/* SECTION D: CHARACTERS (THE PEOPLE BEHIND THE FIGHT)      */}
        {/* ======================================================== */}
        <CharacterDossier />

        {/* ======================================================== */}
        {/* SECTION E: THE WORLD OF PENDEKAR WARRIOR                 */}
        {/* ======================================================== */}
        <section className="py-24 px-6 md:px-10 bg-[#111620]/30 border-t border-[#1F2633]" id="world">
          <div className="max-w-7xl mx-auto">
            {/* Header */}
            <div className="text-center max-w-3xl mx-auto mb-16">
              <span className="font-['Cinzel'] text-xs uppercase tracking-[0.28em] text-[#D4AF57] font-bold block mb-2">
                Authentic Locations
              </span>
              <h2 className="font-['Cinzel'] text-2xl sm:text-4xl text-[#F3F0E8] uppercase tracking-wider font-bold">
                A World of Survival and Shadows
              </h2>
              <p className="font-['Be_Vietnam_Pro'] text-sm sm:text-base text-[#9DA6B5] mt-3">
                From the crowded streets of Jakarta to the quiet highlands of Central Java, every place carries its own dangers, memories, and possibilities.
              </p>
            </div>

            {/* 3 Documentary-Realism Location Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {LOCATIONS.map((loc) => (
                <div
                  key={loc.id}
                  data-cursor="view"
                  className="bg-[#111620] border border-white/10 rounded-xs overflow-hidden flex flex-col group hover:border-[#D4AF57]/50 transition-all duration-300"
                >
                  <div className="relative aspect-[16/10] overflow-hidden">
                    <LazyImage
                      src={loc.img}
                      alt={loc.name}
                      aspectRatioClass="aspect-[16/10]"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#111620] via-transparent to-transparent" />
                    <div className="absolute top-3 left-3 px-2.5 py-1 bg-[#080B10]/80 border border-white/10 text-[10px] font-['Cinzel'] uppercase tracking-[0.16em] text-[#F0D995]">
                      {loc.number} · {loc.tagline}
                    </div>
                  </div>

                  <div className="p-6 flex flex-col flex-1 justify-between gap-4">
                    <div>
                      <h3 className="font-['Cinzel'] text-lg uppercase tracking-wide text-[#F3F0E8] font-bold group-hover:text-[#F0D995] transition-colors">
                        {loc.name}
                      </h3>
                      <p className="font-['Be_Vietnam_Pro'] text-xs sm:text-sm text-[#9DA6B5] mt-2 leading-relaxed">
                        {loc.description}
                      </p>
                      <div className="mt-3 p-2.5 rounded-xs bg-[#080B10]/60 border border-white/5 text-[11px] text-[#9DA6B5]">
                        <span className="text-[#D4AF57] font-['Cinzel'] uppercase tracking-wider block mb-0.5">
                          Atmosphere:
                        </span>
                        {loc.atmosphere}
                      </div>
                    </div>

                    <div className="pt-3 border-t border-white/5 flex items-center justify-between text-[11px] font-['Cinzel'] uppercase tracking-widest text-[#D4AF57]/80">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5" />
                        {loc.region}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ======================================================== */}
        {/* SECTION F: ACTION AND CINEMATIC EXPERIENCE               */}
        {/* ======================================================== */}
        <section className="py-24 px-6 md:px-10 bg-[#080B10] border-t border-[#1F2633]" id="action">
          <div className="max-w-7xl mx-auto">
            {/* Header */}
            <div className="max-w-3xl mb-14">
              <span className="font-['Cinzel'] text-xs uppercase tracking-[0.28em] text-[#D4AF57] font-bold block mb-2">
                Combat &amp; Cinematography
              </span>
              <h2 className="font-['Cinzel'] text-2xl sm:text-4xl text-[#F3F0E8] uppercase tracking-wider font-bold">
                Built on Discipline. Driven by Consequence.
              </h2>
              <p className="font-['Be_Vietnam_Pro'] text-sm sm:text-base text-[#9DA6B5] mt-2">
                Close-quarters combat. Relentless tension. A warrior’s strength tested not only by his enemies, but by the choices he makes when the fight is almost over.
              </p>
            </div>

            {/* Three Pillars */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Pillar 1 */}
              <div className="bg-[#111620]/70 border border-white/10 rounded-xs overflow-hidden flex flex-col group hover:border-[#D4AF57]/40 transition-colors">
                <div className="relative aspect-[16/10] overflow-hidden">
                  <LazyImage
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuDbdVqbWmey-Trozry9qX3Sb4Y5YFeWyt4lJu-IrQp5IXABcQH-tRMZ3H6EN8HKbq2PFgO22rFq36iZvzLYJDc51e-Jz8ZtA3dfuRHo-2I-oGu9D0OpI_4v0IjJjjWjwoSPVlYEj20RoTMrUIs0oMEDVxflJf7bz88KYDaMeUyK3-4lVBycoMw9ZlpNXtYmiNSm1gJYHZrNrdjc9em8m_aNOKaBmu8hVCBxthf_z0qGw24tUgx2wib9HA"
                    alt="Close quarters silat training gathering"
                    aspectRatioClass="aspect-[16/10]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#111620] via-[#111620]/20 to-transparent" />
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-['Cinzel'] text-xs uppercase tracking-[0.2em] text-[#F0D995] font-bold">
                      Combat Design
                    </span>
                  </div>
                  <h3 className="font-['Cinzel'] text-base sm:text-lg uppercase tracking-wide text-[#F3F0E8] font-bold mb-2">
                    Close-Quarters Combat
                  </h3>
                  <p className="font-['Be_Vietnam_Pro'] text-xs sm:text-sm text-[#9DA6B5] leading-relaxed">
                    Tight, physical encounters shaped by timing, awareness, and controlled movement. Gritty Pencak Silat grounded in raw consequence rather than theatrical bravado.
                  </p>
                </div>
              </div>

              {/* Pillar 2 */}
              <div className="bg-[#111620]/70 border border-white/10 rounded-xs overflow-hidden flex flex-col group hover:border-[#D4AF57]/40 transition-colors">
                <div className="relative aspect-[16/10] overflow-hidden">
                  <LazyImage
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuAI1SrGE2lxJit_sUMB910ZT5RFxIyHvkqZY_ajTChFVbX1jVFRpzr4b4jsXwCZqmEUffnCpfhmKdDoOOGqtwS7EcBaFwOu25jxLqi7ydmyUPWsHXcUOV7PNwVrUSilOdMDV1UeK_Kv1zpsMvLQrWhH-ocVpwRfUTAW7t9i84WHcsRz-xTG_yZT6eXfpH-_fsBBaf5FDVUmZtAZHHRn_-5WkrtJddVPihOiHMC7HTrYKgwXb_z7jU3nTA"
                    alt="Road through lush Indonesian terrain into Jakarta"
                    aspectRatioClass="aspect-[16/10]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#111620] via-[#111620]/20 to-transparent" />
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-['Cinzel'] text-xs uppercase tracking-[0.2em] text-[#F0D995] font-bold">
                      Setting
                    </span>
                  </div>
                  <h3 className="font-['Cinzel'] text-base sm:text-lg uppercase tracking-wide text-[#F3F0E8] font-bold mb-2">
                    The Streets of Jakarta
                  </h3>
                  <p className="font-['Be_Vietnam_Pro'] text-xs sm:text-sm text-[#9DA6B5] leading-relaxed">
                    A grounded urban thriller where crowded alleys, markets, garages, warehouses, and nightclubs become part of the action.
                  </p>
                </div>
              </div>

              {/* Pillar 3 */}
              <div className="bg-[#111620]/70 border border-white/10 rounded-xs overflow-hidden flex flex-col group hover:border-[#D4AF57]/40 transition-colors">
                <div className="relative aspect-[16/10] overflow-hidden">
                  <LazyImage
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuDY7s9pCSHSUMp__fuJcVLkCnwFiEgvu0kG8fV93F4XP2hFgIF1Jm9_6P1hMW8f_RW7Z-Xe3O7kwl3CChkziO_i6NGTh24Du53TT_BG1AR2OQVtA94Jn3hNleEjSEczneLUvDwagFF7oLBDdHVjsZ3L8DtOnJXGLpX8eLj60S1gcuygHGn_8c2XGSZfYGHa3eIgfSQgaGClvzh1E5i4sWTvHXehPlJblMAZmEbLbzRS410Eze386p-4lw"
                    alt="Jaya and Rama in grief and confrontation"
                    aspectRatioClass="aspect-[16/10]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#111620] via-[#111620]/20 to-transparent" />
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-['Cinzel'] text-xs uppercase tracking-[0.2em] text-[#F0D995] font-bold">
                      Moral Stakes
                    </span>
                  </div>
                  <h3 className="font-['Cinzel'] text-base sm:text-lg uppercase tracking-wide text-[#F3F0E8] font-bold mb-2">
                    The Final Choice
                  </h3>
                  <p className="font-['Be_Vietnam_Pro'] text-xs sm:text-sm text-[#9DA6B5] leading-relaxed">
                    A personal confrontation that tests whether Jaya can finally break the cycle of revenge and instill life instead of death in his nephew.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ======================================================== */}
        {/* SECTION G: THE CENTRAL CONFLICT (EDITORIAL TWO-PART)     */}
        {/* ======================================================== */}
        <section className="py-24 px-6 md:px-10 bg-[#111620]/50 border-t border-[#1F2633] relative" id="conflict">
          <div className="max-w-7xl mx-auto">
            {/* Header */}
            <div className="text-center max-w-3xl mx-auto mb-16">
              <span className="font-['Cinzel'] text-xs uppercase tracking-[0.28em] text-[#D4AF57] font-bold block mb-2">
                The Moral Core
              </span>
              <h2 className="font-['Cinzel'] text-2xl sm:text-4xl text-[#F3F0E8] uppercase tracking-wider font-bold">
                Strength Is Not the Same as Violence
              </h2>
              <div className="h-0.5 w-20 bg-[#D4AF57]/60 mx-auto mt-4" />
            </div>

            {/* Editorial Split Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
              {/* Left: Cold Shadow Card (The Man Jaya Was) */}
              <div className="relative p-8 md:p-12 rounded-xs bg-gradient-to-b from-[#080B10] to-[#111620] border border-white/5 shadow-xl flex flex-col justify-between">
                <div>
                  <span className="text-[11px] font-['Cinzel'] uppercase tracking-[0.25em] text-[#9DA6B5]/80 block mb-2">
                    The Shadow of Yesterday
                  </span>
                  <h3 className="font-['Cinzel'] text-2xl md:text-3xl font-bold uppercase text-[#F3F0E8]/90 tracking-wide mb-4">
                    The Man Jaya Was
                  </h3>
                  {/* Clean unboxed metadata tags without pills */}
                  <div className="flex flex-wrap items-center gap-2 text-xs font-['Cinzel'] uppercase text-[#9DA6B5] mb-6">
                    <span>Grief</span>
                    <span aria-hidden="true">·</span>
                    <span>Guilt</span>
                    <span aria-hidden="true">·</span>
                    <span>Anger</span>
                    <span aria-hidden="true">·</span>
                    <span>Revenge</span>
                  </div>
                  <p className="font-['Be_Vietnam_Pro'] text-sm sm:text-base text-[#9DA6B5] leading-relaxed">
                    Jaya knows how easily violence can take control. His past has already cost him the life he once knew. In the shadows of his youth, retribution was an immediate impulse that led straight through iron prison gates.
                  </p>
                </div>
                <div className="mt-8 pt-4 border-t border-white/5 flex items-center gap-2 text-xs font-['Cinzel'] uppercase tracking-widest text-[#9DA6B5]/60">
                  <Lock className="w-4 h-4" />
                  <span>The Past He Left Behind</span>
                </div>
              </div>

              {/* Right: Warm Gold Accent Card (The Man He Must Become) */}
              <div className="relative p-8 md:p-12 rounded-xs bg-gradient-to-b from-[#252B35]/60 to-[#111620] border border-[#D4AF57]/30 shadow-[0_0_40px_rgba(212,175,87,0.08)] flex flex-col justify-between">
                <div>
                  <span className="text-[11px] font-['Cinzel'] uppercase tracking-[0.25em] text-[#D4AF57] block mb-2">
                    The Stand for the Future
                  </span>
                  <h3 className="font-['Cinzel'] text-2xl md:text-3xl font-bold uppercase text-[#F0D995] tracking-wide mb-4">
                    The Man He Must Become
                  </h3>
                  <div className="flex flex-wrap items-center gap-2 text-xs font-['Cinzel'] uppercase text-[#F0D995] mb-6">
                    <span>Discipline</span>
                    <span aria-hidden="true">·</span>
                    <span>Responsibility</span>
                    <span aria-hidden="true">·</span>
                    <span>Restraint</span>
                    <span aria-hidden="true">·</span>
                    <span>Protection</span>
                  </div>
                  <p className="font-['Be_Vietnam_Pro'] text-sm sm:text-base text-[#F3F0E8]/90 leading-relaxed">
                    With Rama depending on him, Jaya faces a different kind of battle: finding the strength to stop before violence becomes the only answer. True mastery is not in breaking an enemy, but in safeguarding a child's soul.
                  </p>
                </div>
                <div className="mt-8 pt-4 border-t border-[#D4AF57]/20 flex items-center gap-2 text-xs font-['Cinzel'] uppercase tracking-widest text-[#D4AF57]">
                  <Shield className="w-4 h-4" />
                  <span>The Standard He Must Protect</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ======================================================== */}
        {/* SECTION H: GALLERY                                       */}
        {/* ======================================================== */}
        <section className="py-24 px-6 md:px-10 bg-[#080B10] border-t border-[#1F2633]" id="gallery">
          <div className="max-w-7xl mx-auto">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
              <div>
                <span className="font-['Cinzel'] text-xs uppercase tracking-[0.28em] text-[#D4AF57] font-bold block mb-2">
                  Cinematic Still Photography
                </span>
                <h2 className="font-['Cinzel'] text-2xl sm:text-4xl text-[#F3F0E8] uppercase tracking-wider font-bold">
                  Inside the World of Pendekar Warrior
                </h2>
              </div>
              <p className="font-['Be_Vietnam_Pro'] text-xs sm:text-sm text-[#9DA6B5] max-w-md">
                Click any production still to inspect full widescreen framing captured across Java and Jakarta.
              </p>
            </div>

            {/* Film Stills Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {GALLERY_ITEMS.map((item) => (
                <div
                  key={item.id}
                  data-cursor="view"
                  onClick={() => {
                    triggerHaptic('medium');
                    setSelectedStill(item);
                  }}
                  className="group relative aspect-[16/10] bg-[#111620] overflow-hidden rounded-xs cursor-pointer border border-white/5 hover:border-[#D4AF57]/50 transition-all duration-300"
                >
                  <LazyImage
                    src={item.img}
                    alt={item.title}
                    aspectRatioClass="aspect-[16/10]"
                  />
                  <div className="absolute inset-0 bg-[#080B10]/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Maximize2 className="w-6 h-6 text-[#F0D995]" />
                  </div>
                  <div className="absolute bottom-2 left-2 right-2 px-2.5 py-1 bg-[#080B10]/80 backdrop-blur-sm border border-white/5 text-[10px] font-['Cinzel'] uppercase tracking-wider text-[#F3F0E8] flex justify-between">
                    <span className="truncate">{item.title}</span>
                    <span className="text-[#D4AF57]">{item.category}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ======================================================== */}
        {/* SECTION I: FINAL CALL TO ACTION                          */}
        {/* ======================================================== */}
        <section className="relative py-28 px-6 md:px-10 bg-[#111620] border-t border-[#1F2633] overflow-hidden">
          <div className="relative z-10 max-w-4xl mx-auto text-center flex flex-col items-center">
            <span className="font-['Cinzel'] text-xs uppercase tracking-[0.3em] text-[#F0D995] font-semibold mb-3">
              The Film Ahead
            </span>
            <h2 className="font-['Cinzel'] text-3xl sm:text-5xl font-bold uppercase tracking-wider text-[#F3F0E8]">
              Every Warrior Faces a Choice.
            </h2>
            <p className="font-['Be_Vietnam_Pro'] text-sm sm:text-base text-[#9DA6B5] max-w-xl mt-4 leading-relaxed">
              A story of family, loss, loyalty, and the fight to become something more than your past.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-4 mt-8">
              <InteractiveButton
                variant="gold"
                hapticType="medium"
                onClick={() => setTrailerOpen(true)}
                className="px-8 py-3.5 text-xs sm:text-sm font-bold tracking-[0.2em]"
              >
                <Play className="w-4 h-4 fill-current mr-2" />
                <span>Watch the Trailer</span>
              </InteractiveButton>

              <InteractiveButton
                variant="glass"
                hapticType="light"
                onClick={() => setRsvpOpen(true)}
                className="px-8 py-3.5 text-xs sm:text-sm"
              >
                <Ticket className="w-4 h-4 text-[#D4AF57] mr-2" />
                <span>Request Screening Pass</span>
              </InteractiveButton>
            </div>
          </div>
        </section>

        {/* ======================================================== */}
        {/* SECTION: THE DIRECTOR & PRODUCER (JOHN RADEL, ACS)       */}
        {/* Placed immediately after 'The Film Ahead' CTA section    */}
        {/* ======================================================== */}
        <DirectorSection />
      </main>

      {/* ======================================================== */}
      {/* SECTION J: FOOTER & PRODUCTION CREDITS                   */}
      {/* ======================================================== */}
      <footer className="bg-[#080B10] border-t border-white/10 py-16 px-6 md:px-10 text-[#9DA6B5] font-['Be_Vietnam_Pro']" id="contact">
        <div className="max-w-7xl mx-auto flex flex-col gap-12">
          {/* Top Row: Brand & Production Credits */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start pb-10 border-b border-white/5">
            <div className="lg:col-span-6 flex flex-col">
              <div className="flex flex-col mb-1">
                <span className="font-['Cinzel'] text-[11px] font-bold tracking-[0.35em] text-[#9DA6B5] uppercase">
                  IKO UWAIS
                </span>
                <a
                  href="https://www.imdb.com/title/tt39331600/?ref_=ext_shr_lnk"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-['Cinzel'] text-2xl sm:text-3xl font-black uppercase tracking-[0.18em] text-[#F3F0E8] hover:text-[#F0D995] transition-colors leading-tight inline-flex items-center gap-2"
                  title="View Pendekar Warrior on IMDb"
                >
                  <span>WARRIOR</span>
                  <span className="px-1.5 py-0.5 rounded-xs bg-[#f5c518] text-[#000000] font-sans font-black text-[10px] tracking-normal">
                    IMDb
                  </span>
                </a>
                <span className="font-['Cinzel'] text-xs font-semibold tracking-[0.32em] text-[#D4AF57]/90">
                  (PENDEKAR)
                </span>
              </div>
              <p className="font-['Cinzel'] text-xs uppercase tracking-[0.22em] text-[#D4AF57] font-semibold mt-1">
                The hardest fight is the one within.
              </p>
              <div className="mt-6 flex flex-col gap-2 text-xs">
                <p className="text-[#F3F0E8]/90">
                  <strong className="text-[#F0D995] font-medium font-['Cinzel'] tracking-wider">
                    Production Company:
                  </strong>{' '}
                  <a
                    href="https://asiamediaalliancegroup.com/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#F0D995] hover:text-[#F3F0E8] hover:underline transition-colors inline-flex items-center gap-1 font-semibold ml-1"
                  >
                    Asia Media Alliance Group (PT Asia Media Aliansi Group){' '}
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </p>
                <p className="text-[#F3F0E8]/90">
                  <strong className="text-[#F0D995] font-medium font-['Cinzel'] tracking-wider">
                    Production Service Company:
                  </strong>{' '}
                  <span className="text-[#F3F0E8] font-semibold ml-1">
                    WAVE FILMS SDN. BHD.
                  </span>
                </p>
                <p className="text-[#9DA6B5]">
                  <strong className="text-[#F0D995] font-medium font-['Cinzel'] tracking-wider">
                    Original Story &amp; Screenplay:
                  </strong>{' '}
                  <a
                    href="https://www.imdb.com/name/nm1634700/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#F0D995] hover:text-[#F3F0E8] hover:underline transition-colors inline-flex items-center gap-1 font-semibold ml-1"
                  >
                    John Radel <ExternalLink className="w-3 h-3" />
                  </a>
                </p>
                <p className="text-[#9DA6B5]">
                  <strong className="text-[#F0D995] font-medium font-['Cinzel'] tracking-wider">
                    Current Revisions:
                  </strong>{' '}
                  Niall Johnson
                </p>
                <p className="text-[#9DA6B5]">
                  <strong className="text-[#F0D995] font-medium font-['Cinzel'] tracking-wider">
                    Filming Location:
                  </strong>{' '}
                  <span className="text-[#F3F0E8] font-medium ml-1">
                    IMS (Iskandar Malaysia Studios)
                  </span>
                </p>
              </div>
            </div>

            {/* Navigation Mirror */}
            <div className="lg:col-span-6 flex flex-wrap gap-6 lg:gap-8 justify-start lg:justify-end text-xs font-['Cinzel'] uppercase tracking-[0.18em] items-center">
              <a
                className="text-[#D4AF57] hover:text-[#F0D995] transition-colors inline-flex items-center gap-1 font-bold"
                href="https://asiamediaalliancegroup.com/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Building2 className="w-3.5 h-3.5" />
                Asia Media Alliance Group
              </a>
              <a
                className="text-[#f5c518] hover:text-[#e2b616] transition-colors inline-flex items-center gap-1 font-bold font-sans"
                href="https://www.imdb.com/title/tt39331600/?ref_=ext_shr_lnk"
                target="_blank"
                rel="noopener noreferrer"
              >
                IMDb Title <ExternalLink className="w-3 h-3" />
              </a>
              <a className="hover:text-[#F0D995] transition-colors" href="#film">The Film</a>
              <a className="hover:text-[#F0D995] transition-colors" href="#story">Story</a>
              <a className="hover:text-[#F0D995] transition-colors" href="#characters">Characters</a>
              <a className="hover:text-[#F0D995] transition-colors" href="#world">World</a>
              <a className="hover:text-[#F0D995] transition-colors" href="#gallery">Gallery</a>
              <a className="hover:text-[#F0D995] transition-colors" href="#director">Director</a>
              <button
                onClick={() => setRsvpOpen(true)}
                className="hover:text-[#F0D995] transition-colors uppercase cursor-pointer"
              >
                RSVP Pass
              </button>
            </div>
          </div>

          {/* Bottom Row */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
            <p>
              © 2026{' '}
              <a
                href="https://asiamediaalliancegroup.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#F3F0E8] hover:text-[#F0D995] hover:underline transition-colors"
              >
                Asia Media Alliance Group
              </a>
              . All rights reserved.
            </p>
            <p className="text-[#9DA6B5]/80 text-[11px] tracking-wide">
              Filmed at IMS (Iskandar Malaysia Studios) • Production Service Company: WAVE FILMS SDN. BHD.
            </p>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <TrailerModal
        isOpen={trailerOpen}
        onClose={() => setTrailerOpen(false)}
        onOpenRSVP={() => setRsvpOpen(true)}
      />

      <RSVPScreeningModal
        isOpen={rsvpOpen}
        onClose={() => setRsvpOpen(false)}
      />

      <GalleryModal
        still={selectedStill}
        allStills={GALLERY_ITEMS}
        onClose={() => setSelectedStill(null)}
        onSelectStill={(still) => setSelectedStill(still)}
      />
    </div>
  );
}
