/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Play, Volume2, VolumeX, ShieldCheck, Film, ExternalLink } from 'lucide-react';
import { InteractiveButton } from './InteractiveButton';
import { triggerHaptic } from '../utils/haptics';

interface TrailerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenRSVP: () => void;
}

export const TrailerModal: React.FC<TrailerModalProps> = ({
  isOpen,
  onClose,
  onOpenRSVP,
}) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#080B10]/95 backdrop-blur-2xl">
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-4xl bg-[#111620] border border-white/10 rounded-xs overflow-hidden shadow-[0_20px_70px_rgba(0,0,0,0.9)]"
        >
          {/* Close Button */}
          <button
            onClick={() => {
              triggerHaptic('light');
              onClose();
            }}
            aria-label="Close Trailer Modal"
            className="absolute top-4 right-4 z-30 p-2 text-[#9DA6B5] hover:text-[#F3F0E8] bg-[#080B10]/80 rounded-full border border-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Video / Still Canvas Preview */}
          <div className="relative aspect-[16/9] w-full bg-[#080B10] flex flex-col items-center justify-center text-center p-6 overflow-hidden">
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuCD5NuCBMMe1JTjomcVrMqo6YXHL6E4FRUm4J2jsW9yG88eXJyD_NZus6YLCycQiJvJg9m7b_97Q1zkSvEvR3mVG1QJdizd-M9N5OW5evYBXG7nlO1od37ykHPLMDwPxroyJPVpTfXBtK_okeqxU063zrvocudHYBuJ399t4I4kmbFu1pUOYCELccxMXGvQ4MvzgoiiTEKLCSS_kIa7L_6vXsRWAZVsqRh7YqD4X3PqXFjUXM6BqtTZfA"
              alt="Teaser Preview Still"
              className="absolute inset-0 w-full h-full object-cover opacity-35 filter brightness-75 scale-105 transition-transform duration-1000"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#111620] via-transparent to-[#111620]/80" />

            {/* Teaser Center Canvas */}
            <div className="relative z-10 flex flex-col items-center max-w-lg px-4">
              <motion.div
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
                className="w-16 h-16 rounded-full border border-[#D4AF57] bg-[#080B10]/60 backdrop-blur-md flex items-center justify-center text-[#D4AF57] mb-4 shadow-[0_0_30px_rgba(212,175,87,0.3)] cursor-pointer"
                onClick={() => {
                  triggerHaptic('medium');
                  setIsPlaying(!isPlaying);
                }}
              >
                {isPlaying ? <Film className="w-7 h-7" /> : <Play className="w-7 h-7 ml-0.5" />}
              </motion.div>

              <span className="font-['Cinzel'] text-xs uppercase tracking-[0.3em] text-[#F0D995] font-bold">
                Official Teaser Preview
              </span>
              <h4 className="font-['Cinzel'] text-2xl sm:text-3xl text-[#F3F0E8] font-black uppercase tracking-wider mt-2 drop-shadow-lg">
                WARRIOR (PENDEKAR)
              </h4>
              <p className="font-['Be_Vietnam_Pro'] text-xs sm:text-sm text-[#9DA6B5] mt-3 leading-relaxed">
                The official festival teaser trailer premieres exclusively at upcoming domestic and international theatrical festivals. Early screening passes can be reserved below.
              </p>

              {/* Sound toggle & playback controls */}
              <div className="flex items-center gap-4 mt-6">
                <InteractiveButton
                  variant="gold"
                  hapticType="success"
                  onClick={() => {
                    onClose();
                    onOpenRSVP();
                  }}
                >
                  Reserve Screener Pass
                </InteractiveButton>

                <button
                  onClick={() => {
                    triggerHaptic('light');
                    setIsMuted(!isMuted);
                  }}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xs border border-white/10 bg-[#080B10]/80 text-[#9DA6B5] hover:text-[#F3F0E8] text-xs font-['Cinzel'] cursor-pointer"
                >
                  {isMuted ? <VolumeX className="w-4 h-4 text-amber-400" /> : <Volume2 className="w-4 h-4 text-[#D4AF57]" />}
                  <span>{isMuted ? 'Muted' : 'Sound Active'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Credits Strip */}
          <div className="p-4 sm:p-5 bg-[#080B10] border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs font-['Cinzel'] text-[#9DA6B5]">
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#D4AF57]" />
                <span>Production:</span>
                <a
                  href="https://asiamediaalliancegroup.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#F0D995] hover:underline inline-flex items-center gap-1 font-bold"
                >
                  Asia Media Alliance Group <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              <span className="text-white/20">·</span>
              <div className="flex items-center gap-1 text-[#F3F0E8]">
                <span className="text-[#9DA6B5]">Services:</span>
                <span className="text-[#F0D995] font-semibold">WAVE FILMS SDN. BHD.</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 text-[11px]">
              <div>
                Screenplay by{' '}
                <a
                  href="https://www.imdb.com/name/nm1634700/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#F0D995] hover:underline inline-flex items-center gap-0.5 font-semibold"
                >
                  John Radel <ExternalLink className="w-2.5 h-2.5" />
                </a>{' '}
                • Revisions by Niall Johnson
              </div>
              <a
                href="https://www.imdb.com/title/tt39331600/?ref_=ext_shr_lnk"
                target="_blank"
                rel="noopener noreferrer"
                className="px-2 py-0.5 rounded-xs bg-[#f5c518] text-[#000000] font-black font-sans text-[10px] tracking-normal hover:bg-[#e2b616] transition-colors inline-flex items-center gap-1"
              >
                IMDb <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
