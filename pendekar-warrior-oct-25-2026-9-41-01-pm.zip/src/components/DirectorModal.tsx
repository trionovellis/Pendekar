/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Award, Film, Users, Clapperboard, ExternalLink, Sparkles } from 'lucide-react';
import { DirectorFilm } from '../data/directorData';
import { triggerHaptic } from '../utils/haptics';
import { InteractiveButton } from './InteractiveButton';

interface DirectorModalProps {
  film: DirectorFilm | null;
  onClose: () => void;
}

export const DirectorModal: React.FC<DirectorModalProps> = ({ film, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (film) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [film, onClose]);

  if (!film) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#080B10]/95 backdrop-blur-2xl">
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 15 }}
          transition={{ type: 'spring', damping: 25, stiffness: 320 }}
          className="relative w-full max-w-2xl bg-[#111620] border border-[#D4AF57]/40 rounded-xs shadow-[0_20px_70px_rgba(0,0,0,0.9)] overflow-hidden"
        >
          {/* Header Graphic Strip with Atmospheric Color Wash */}
          <div className={`relative h-24 sm:h-28 bg-gradient-to-r ${film.posterBg} p-5 sm:p-6 flex flex-col justify-end border-b border-white/10`}>
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent pointer-events-none" />
            
            {/* Close Button */}
            <button
              onClick={() => {
                triggerHaptic('light');
                onClose();
              }}
              aria-label="Close Film Dossier"
              className="absolute top-4 right-4 z-20 p-2 rounded-full bg-[#080B10]/85 text-[#9DA6B5] hover:text-[#F3F0E8] hover:bg-[#080B10] border border-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="relative z-10 flex items-center gap-2 mb-1">
              <span className="font-['Cinzel'] text-[11px] font-bold uppercase tracking-[0.25em] text-[#D4AF57]">
                John Radel Filmography
              </span>
              <span className="text-white/30">·</span>
              <span className="text-[11px] font-['Cinzel'] uppercase tracking-wider text-[#F0D995]">
                {film.year}
              </span>
            </div>
            <h3 className="relative z-10 font-['Cinzel'] text-xl sm:text-3xl font-black uppercase tracking-wider text-[#F3F0E8] drop-shadow-md">
              {film.title}
            </h3>
          </div>

          {/* Modal Body */}
          <div className="p-5 sm:p-7 space-y-6 max-h-[75vh] overflow-y-auto custom-scroll">
            {/* Top Grid: Poster Preview + Key Role / Studio Info */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-5 items-start pb-4 border-b border-white/5">
              {/* Left: Film Poster */}
              <div className="sm:col-span-4 relative aspect-[2/3] rounded-xs overflow-hidden border border-[#D4AF57]/40 bg-[#080B10] shadow-md max-w-[180px] mx-auto sm:mx-0 w-full">
                <img
                  src={film.posterImg}
                  alt={`${film.title} Official Theatrical Poster`}
                  className="w-full h-full object-cover"
                  loading="lazy"
                  onError={(e) => {
                    // Fallback to stylized poster background if image fails
                    (e.currentTarget as HTMLElement).style.display = 'none';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#080B10]/70 via-transparent to-transparent pointer-events-none" />
                <span className="absolute bottom-2 left-2 right-2 text-center text-[9px] font-['Cinzel'] uppercase tracking-wider text-[#F0D995] bg-[#080B10]/90 px-1 py-0.5 rounded-xs border border-white/10">
                  {film.tag}
                </span>
              </div>

              {/* Right: Key Details */}
              <div className="sm:col-span-8 flex flex-col gap-3">
                <div className="p-3 bg-[#080B10] border border-white/5 rounded-xs">
                  <span className="font-['Cinzel'] text-[10px] uppercase tracking-wider text-[#D4AF57] block mb-0.5 font-bold">
                    John Radel’s Role
                  </span>
                  <span className="font-['Cinzel'] text-xs uppercase font-bold text-[#F3F0E8] tracking-wide">
                    {film.role}
                  </span>
                </div>

                <div className="p-3 bg-[#080B10] border border-white/5 rounded-xs">
                  <span className="font-['Cinzel'] text-[10px] uppercase tracking-wider text-[#D4AF57] block mb-0.5 font-bold">
                    Director &amp; Studio
                  </span>
                  <span className="font-['Be_Vietnam_Pro'] text-xs font-medium text-[#F3F0E8] block">
                    Dir: {film.director}
                  </span>
                  <span className="font-['Be_Vietnam_Pro'] text-[11px] text-[#9DA6B5] block mt-0.5">
                    {film.studio}
                  </span>
                </div>

                {film.awards && (
                  <div className="flex items-start gap-2.5 p-3 bg-[#D4AF57]/10 border border-[#D4AF57]/30 rounded-xs">
                    <Award className="w-4 h-4 text-[#D4AF57] shrink-0 mt-0.5" />
                    <div>
                      <span className="font-['Cinzel'] text-[10px] uppercase tracking-widest text-[#F0D995] font-bold block mb-0.5">
                        Accolades &amp; Recognition
                      </span>
                      <p className="font-['Be_Vietnam_Pro'] text-xs text-[#F3F0E8] leading-relaxed">
                        {film.awards}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Synopsis */}
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <Clapperboard className="w-4 h-4 text-[#D4AF57]" />
                <span className="font-['Cinzel'] text-xs uppercase tracking-wider text-[#F0D995] font-bold">
                  Synopsis
                </span>
              </div>
              <p className="font-['Be_Vietnam_Pro'] text-xs sm:text-sm text-[#9DA6B5] leading-relaxed">
                {film.synopsis}
              </p>
            </div>

            {/* John Radel's Cinematography / Production Notes */}
            <div className="p-4 bg-[#080B10]/80 border border-white/5 rounded-xs">
              <div className="flex items-center gap-2 mb-1.5">
                <Sparkles className="w-4 h-4 text-[#D4AF57]" />
                <span className="font-['Cinzel'] text-xs uppercase tracking-wider text-[#F0D995] font-bold">
                  Cinematography &amp; Production Notes
                </span>
              </div>
              <p className="font-['Be_Vietnam_Pro'] text-xs text-[#9DA6B5] leading-relaxed italic">
                "{film.craftNotes}"
              </p>
            </div>

            {/* Featured Cast */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Users className="w-4 h-4 text-[#D4AF57]" />
                <span className="font-['Cinzel'] text-xs uppercase tracking-wider text-[#F0D995] font-bold">
                  Principal Cast
                </span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {film.cast.map((actor, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-1 bg-[#080B10] border border-white/10 text-xs font-['Be_Vietnam_Pro'] text-[#F3F0E8] rounded-xs"
                  >
                    {actor}
                  </span>
                ))}
              </div>
            </div>

            {/* Footer CTAs */}
            <div className="flex items-center justify-between pt-4 border-t border-white/10">
              {film.imdbUrl ? (
                <a
                  href={film.imdbUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-2 rounded-xs bg-[#f5c518] hover:bg-[#e2b616] text-[#000000] font-sans font-black text-xs tracking-normal transition-colors inline-flex items-center gap-1.5"
                >
                  <span>View on IMDb</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              ) : (
                <div />
              )}

              <InteractiveButton
                variant="subtle"
                hapticType="light"
                onClick={onClose}
                className="px-5 py-2 text-xs"
              >
                Close Dossier
              </InteractiveButton>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
