/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Image as ImageIcon } from 'lucide-react';

interface LazyImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  aspectRatioClass?: string;
  containerClassName?: string;
  zoomOnHover?: boolean;
}

export const LazyImage: React.FC<LazyImageProps> = ({
  src,
  alt,
  aspectRatioClass = 'aspect-[16/10]',
  containerClassName = '',
  zoomOnHover = true,
  className = '',
  ...props
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);

  return (
    <div
      className={`relative overflow-hidden bg-[#111620] ${aspectRatioClass} ${containerClassName}`}
    >
      {/* Shimmer skeleton while loading */}
      {!isLoaded && !hasError && (
        <div className="absolute inset-0 bg-gradient-to-r from-[#111620] via-[#1f2633] to-[#111620] animate-pulse">
          <div className="w-full h-full opacity-20 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#D4AF57] via-transparent to-transparent" />
        </div>
      )}

      {/* Fallback container if image fails to load */}
      {hasError ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center p-4 bg-[#111620] border border-white/5 text-center">
          <ImageIcon className="w-8 h-8 text-[#D4AF57]/60 mb-2" />
          <span className="font-['Cinzel'] text-xs uppercase tracking-wider text-[#9DA6B5]">
            {alt || 'Production Still'}
          </span>
          <span className="text-[10px] text-[#9DA6B5]/60 mt-1 font-['Cinzel']">
            PENDEKAR WARRIOR ARCHIVE
          </span>
        </div>
      ) : (
        <img
          src={src}
          alt={alt}
          loading="lazy"
          decoding="async"
          referrerPolicy="no-referrer"
          onLoad={() => setIsLoaded(true)}
          onError={() => setHasError(true)}
          className={`w-full h-full object-cover transition-all duration-700 ease-out ${
            zoomOnHover ? 'group-hover:scale-105' : ''
          } ${
            isLoaded
              ? 'opacity-100 filter blur-0 scale-100'
              : 'opacity-0 filter blur-sm scale-102'
          } ${className}`}
          {...props}
        />
      )}
    </div>
  );
};
