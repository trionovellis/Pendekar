/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CHAPTERS, ScreenplayChapter } from '../data/filmData';
import { triggerHaptic } from '../utils/haptics';
import { Compass, BookOpen, ChevronRight } from 'lucide-react';

export const ChapterTimeline: React.FC = () => {
  const [activeChapterId, setActiveChapterId] = useState(CHAPTERS[0].id);

  const activeChapter = CHAPTERS.find((c) => c.id === activeChapterId) || CHAPTERS[0];

  return (
    <div className="mt-14 pt-10 border-t border-white/10">
      {/* Section Subtitle */}
      <div className="flex items-center gap-2 mb-6">
        <BookOpen className="w-4 h-4 text-[#D4AF57]" />
        <span className="font-['Cinzel'] text-xs uppercase tracking-[0.25em] text-[#F0D995] font-bold">
          Screenplay Progression
        </span>
      </div>

      {/* Chapter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 custom-scroll">
        {CHAPTERS.map((item) => {
          const isActive = item.id === activeChapterId;
          return (
            <button
              key={item.id}
              onClick={() => {
                triggerHaptic('selection');
                setActiveChapterId(item.id);
              }}
              className={`px-4 py-2.5 rounded-xs border text-xs font-['Cinzel'] uppercase tracking-wider transition-all duration-300 shrink-0 cursor-pointer flex items-center gap-2 ${
                isActive
                  ? 'border-[#D4AF57] bg-[#D4AF57] text-[#080B10] font-bold shadow-[0_0_20px_rgba(212,175,87,0.3)]'
                  : 'border-white/10 bg-[#111620] text-[#9DA6B5] hover:text-[#F3F0E8] hover:border-white/30'
              }`}
            >
              <span className="text-[10px] opacity-75">{item.chapter}</span>
              <span>{item.title}</span>
            </button>
          );
        })}
      </div>

      {/* Chapter Content Card with Silky Transition */}
      <div className="mt-4 p-6 sm:p-8 bg-[#111620] border border-white/10 rounded-xs shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 text-8xl font-black font-['Cinzel'] text-white/5 pointer-events-none select-none">
          {activeChapter.chapter}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeChapter.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.35, ease: 'easeOut' }}
            className="relative z-10 flex flex-col gap-4"
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <span className="text-[11px] font-['Cinzel'] uppercase tracking-[0.25em] text-[#D4AF57] block">
                  Act {activeChapter.chapter} • Narrative Turning Point
                </span>
                <h3 className="font-['Cinzel'] text-xl sm:text-2xl font-bold uppercase text-[#F3F0E8] tracking-wider mt-1">
                  {activeChapter.title}
                </h3>
              </div>

              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xs bg-[#080B10] border border-white/10 text-xs font-['Cinzel'] text-[#F0D995]">
                <Compass className="w-3.5 h-3.5 text-[#D4AF57]" />
                <span>{activeChapter.location}</span>
              </div>
            </div>

            <blockquote className="font-['Be_Vietnam_Pro'] text-sm sm:text-base italic text-[#F0D995]/90 border-l-2 border-[#D4AF57]/60 pl-4 py-1 leading-relaxed">
              "{activeChapter.quote}"
            </blockquote>

            <p className="font-['Be_Vietnam_Pro'] text-xs sm:text-sm text-[#9DA6B5] leading-relaxed max-w-3xl">
              {activeChapter.synopsis}
            </p>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};
