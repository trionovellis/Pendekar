/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCircle, Ticket, WifiOff, Sparkles, Building2 } from 'lucide-react';
import { queueSyncAction } from '../utils/syncManager';
import { triggerHaptic } from '../utils/haptics';
import { InteractiveButton } from './InteractiveButton';

interface RSVPScreeningModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RSVPScreeningModal: React.FC<RSVPScreeningModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [tier, setTier] = useState<'festival_pass' | 'press_screener' | 'industry_distributor'>('festival_pass');
  const [city, setCity] = useState('Jakarta');
  const [submitted, setSubmitted] = useState(false);
  const [wasOffline, setWasOffline] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please provide your name.');
      triggerHaptic('heavy');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setError('Please provide a valid email address.');
      triggerHaptic('heavy');
      return;
    }

    const isOffline = typeof navigator !== 'undefined' && !navigator.onLine;
    setWasOffline(isOffline);

    // Queue in offline sync manager!
    const action = queueSyncAction('rsvp', {
      name,
      email,
      tier,
      city,
      timestamp: new Date().toISOString(),
      film: 'PENDEKAR WARRIOR',
    });

    triggerHaptic('success');
    setSubmitted(true);
  };

  const handleReset = () => {
    setName('');
    setEmail('');
    setSubmitted(false);
    setError(null);
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#080B10]/95 backdrop-blur-2xl">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-lg bg-[#111620] border border-[#D4AF57]/40 rounded-xs shadow-2xl p-6 sm:p-8 overflow-hidden"
        >
          {/* Close button */}
          <button
            onClick={() => {
              triggerHaptic('light');
              onClose();
            }}
            className="absolute top-4 right-4 p-1.5 text-[#9DA6B5] hover:text-[#F3F0E8] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          {!submitted ? (
            <form onSubmit={handleSubmit} className="flex flex-col gap-5">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Ticket className="w-4 h-4 text-[#D4AF57]" />
                  <span className="font-['Cinzel'] text-xs uppercase tracking-[0.25em] text-[#F0D995] font-bold">
                    Theatrical Screening Access
                  </span>
                </div>
                <h3 className="font-['Cinzel'] text-2xl font-bold uppercase text-[#F3F0E8] tracking-wider">
                  Reserve Screener Pass
                </h3>
                <p className="font-['Be_Vietnam_Pro'] text-xs text-[#9DA6B5] mt-1.5 leading-relaxed">
                  Join the exclusive festival premiere waitlist and advance industry screener access for PENDEKAR WARRIOR.
                </p>
              </div>

              {error && (
                <div className="p-3 bg-red-950/40 border border-red-500/30 rounded-xs text-xs text-red-300">
                  {error}
                </div>
              )}

              {/* Pass Tier Selection */}
              <div>
                <label className="block text-xs font-['Cinzel'] uppercase tracking-wider text-[#9DA6B5] mb-2">
                  Pass Classification
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'festival_pass', label: 'Festival VIP' },
                    { id: 'press_screener', label: 'Press / Media' },
                    { id: 'industry_distributor', label: 'Distributor' },
                  ].map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => {
                        triggerHaptic('selection');
                        setTier(t.id as typeof tier);
                      }}
                      className={`py-2 px-2 text-[11px] font-['Cinzel'] uppercase tracking-wider rounded-xs border transition-all cursor-pointer ${
                        tier === t.id
                          ? 'border-[#D4AF57] bg-[#D4AF57]/15 text-[#F0D995] font-bold'
                          : 'border-white/10 bg-[#080B10] text-[#9DA6B5] hover:border-white/20'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Name field */}
              <div>
                <label className="block text-xs font-['Cinzel'] uppercase tracking-wider text-[#9DA6B5] mb-1.5">
                  Full Name / Representative
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="e.g. John Radel"
                  className="w-full px-4 py-2.5 rounded-xs bg-[#080B10] border border-white/10 focus:border-[#D4AF57] focus:outline-none text-[#F3F0E8] text-xs font-['Be_Vietnam_Pro'] transition-colors"
                />
              </div>

              {/* Email field */}
              <div>
                <label className="block text-xs font-['Cinzel'] uppercase tracking-wider text-[#9DA6B5] mb-1.5">
                  Official Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="name@asiamediaalliancegroup.com"
                  className="w-full px-4 py-2.5 rounded-xs bg-[#080B10] border border-white/10 focus:border-[#D4AF57] focus:outline-none text-[#F3F0E8] text-xs font-['Be_Vietnam_Pro'] transition-colors"
                />
              </div>

              {/* City */}
              <div>
                <label className="block text-xs font-['Cinzel'] uppercase tracking-wider text-[#9DA6B5] mb-1.5">
                  Preferred Premiere City
                </label>
                <select
                  value={city}
                  onChange={(e) => {
                    triggerHaptic('selection');
                    setCity(e.target.value);
                  }}
                  className="w-full px-4 py-2.5 rounded-xs bg-[#080B10] border border-white/10 focus:border-[#D4AF57] focus:outline-none text-[#F3F0E8] text-xs font-['Be_Vietnam_Pro'] transition-colors"
                >
                  <option value="Jakarta">Jakarta (Indonesian Gala)</option>
                  <option value="Yogyakarta">Yogyakarta / Central Java</option>
                  <option value="Singapore">Singapore Asian Film Market</option>
                  <option value="Busan">Busan International Film Festival</option>
                  <option value="Toronto">TIFF / International</option>
                </select>
              </div>

              {/* Submit CTA */}
              <div className="pt-2">
                <InteractiveButton
                  type="submit"
                  variant="gold"
                  hapticType="success"
                  className="w-full py-3 text-xs"
                >
                  Confirm Reservation & Sync
                </InteractiveButton>
                <p className="text-[10px] text-center text-[#9DA6B5]/70 mt-2 font-['Be_Vietnam_Pro']">
                  Protected with background offline sync. Safe to submit even with intermittent connection.
                </p>
              </div>
            </form>
          ) : (
            <div className="flex flex-col items-center text-center py-4">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', damping: 15 }}
                className="w-16 h-16 rounded-full bg-[#D4AF57]/20 border border-[#D4AF57] flex items-center justify-center text-[#F0D995] mb-4"
              >
                <CheckCircle className="w-8 h-8" />
              </motion.div>

              <h3 className="font-['Cinzel'] text-xl sm:text-2xl font-bold uppercase text-[#F3F0E8] tracking-wider">
                {wasOffline ? 'Pass Queued In Offline Cache' : 'Screener Request Confirmed'}
              </h3>

              <p className="font-['Be_Vietnam_Pro'] text-xs sm:text-sm text-[#9DA6B5] max-w-sm mt-3 leading-relaxed">
                {wasOffline ? (
                  <>
                    Your reservation for <strong>{name}</strong> was saved to your device’s local offline storage. When you reconnect, the background engine will automatically deliver it to Asia Media Alliance Group!
                  </>
                ) : (
                  <>
                    Thank you, <strong>{name}</strong>. Your screening pass request for {city} has been received and synchronized with production coordinators.
                  </>
                )}
              </p>

              <div className="mt-6 flex flex-col gap-2 w-full">
                <InteractiveButton
                  variant="outline"
                  onClick={handleReset}
                  className="w-full py-2.5"
                >
                  Return to Film
                </InteractiveButton>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
