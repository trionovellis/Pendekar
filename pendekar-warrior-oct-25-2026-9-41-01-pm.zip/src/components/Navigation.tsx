/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Play, Menu, X, Sparkles, VolumeX } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { isHapticsEnabled, setHapticsEnabled, triggerHaptic } from '../utils/haptics';
import { InteractiveButton } from './InteractiveButton';

interface NavigationProps {
  onOpenTrailer: () => void;
  onOpenRSVP: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  onOpenTrailer,
  onOpenRSVP,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [hapticsOn, setHapticsOn] = useState(isHapticsEnabled());

  const toggleHaptics = () => {
    const nextState = !hapticsOn;
    setHapticsEnabled(nextState);
    setHapticsOn(nextState);
    if (nextState) {
      triggerHaptic('medium');
    }
  };

  const navLinks = [
    { label: 'The Film', href: '#film' },
    { label: 'Story', href: '#story' },
    { label: 'Characters', href: '#characters' },
    { label: 'World', href: '#world' },
    { label: 'Action', href: '#action' },
    { label: 'Conflict', href: '#conflict' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'Director', href: '#director' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#080B10]/85 backdrop-blur-xl border-b border-white/5 transition-all duration-300">
      <div className="max-w-7xl mx-auto h-20 px-4 sm:px-6 md:px-10 flex items-center justify-between gap-3 sm:gap-8">
        {/* Zone 1: Brand Wordmark (Single Text Element) */}
        <a
          href="#"
          data-cursor="pointer"
          className="flex flex-col text-left group whitespace-nowrap shrink-0"
        >
          <span className="font-['Cinzel'] text-[9px] sm:text-[10px] md:text-[11px] font-bold tracking-[0.32em] text-[#9DA6B5] uppercase group-hover:text-[#F0D995] transition-colors">
            IKO UWAIS
          </span>
          <span className="font-['Cinzel'] text-lg sm:text-xl md:text-2xl font-black tracking-[0.16em] text-[#F3F0E8] group-hover:text-[#F0D995] transition-colors uppercase leading-tight drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)]">
            WARRIOR
          </span>
          <span className="text-[9px] sm:text-[10px] md:text-[11px] uppercase font-['Cinzel'] font-semibold tracking-[0.32em] text-[#D4AF57]/90 -mt-0.5">
            (PENDEKAR)
          </span>
        </a>

        {/* Zone 2: 4–5 Concise Nav Links */}
        <nav className="hidden lg:flex items-center gap-7">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              data-cursor="pointer"
              onClick={() => triggerHaptic('light')}
              className="text-xs uppercase font-medium tracking-[0.18em] text-[#9DA6B5] hover:text-[#D4AF57] transition-colors whitespace-nowrap shrink-0"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: 1 Primary Action + Haptics Switcher & Mobile Hamburger */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Subtle Tactile Haptics Switcher Button */}
          <button
            onClick={toggleHaptics}
            title={hapticsOn ? 'Tactile Haptics & Acoustic Feedback Active' : 'Tactile Haptics Muted'}
            aria-label="Toggle Tactile Haptics"
            className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 sm:px-3 sm:py-1.5 rounded-xs border text-[10px] sm:text-[11px] font-['Cinzel'] uppercase tracking-wider transition-colors cursor-pointer ${
              hapticsOn
                ? 'border-[#D4AF57]/40 bg-[#D4AF57]/10 text-[#F0D995]'
                : 'border-white/10 bg-[#111620] text-[#9DA6B5]'
            }`}
          >
            {hapticsOn ? <Sparkles className="w-3.5 h-3.5 text-[#D4AF57]" /> : <VolumeX className="w-3.5 h-3.5 text-[#9DA6B5]" />}
            <span className="hidden md:inline">{hapticsOn ? 'Haptics: On' : 'Haptics: Off'}</span>
          </button>

          {/* Primary Action Button (desktop / tablet) */}
          <div className="hidden md:block">
            <InteractiveButton
              variant="outline"
              hapticType="medium"
              onClick={onOpenTrailer}
              cursorLabel="play"
              className="px-4 py-2 text-xs"
            >
              <Play className="w-3 h-3 fill-current mr-1.5" />
              <span>Watch Trailer</span>
            </InteractiveButton>
          </div>

          {/* Mobile Menu Trigger */}
          <button
            onClick={() => {
              triggerHaptic('light');
              setMobileMenuOpen(!mobileMenuOpen);
            }}
            aria-label="Toggle Navigation Menu"
            className="lg:hidden p-2 text-[#F3F0E8] hover:text-[#D4AF57] transition-colors cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            className="lg:hidden bg-[#111620] border-b border-white/10 px-6 py-6 overflow-hidden"
          >
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => {
                    triggerHaptic('light');
                    setMobileMenuOpen(false);
                  }}
                  className="text-sm uppercase tracking-[0.16em] text-[#F3F0E8] hover:text-[#D4AF57] transition-colors"
                >
                  {link.label}
                </a>
              ))}

              <div className="pt-4 border-t border-white/10 flex flex-col gap-3">
                <InteractiveButton
                  variant="gold"
                  hapticType="medium"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenTrailer();
                  }}
                  className="w-full flex items-center justify-center gap-2 py-3"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>Watch the Trailer</span>
                </InteractiveButton>

                <InteractiveButton
                  variant="glass"
                  hapticType="light"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenRSVP();
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2.5 text-xs"
                >
                  <span>VIP Screener RSVP</span>
                </InteractiveButton>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
