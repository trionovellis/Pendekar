/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';

export const CustomCursor: React.FC = () => {
  const outerRef = useRef<HTMLDivElement | null>(null);
  const dotRef = useRef<HTMLDivElement | null>(null);
  const textRef = useRef<HTMLSpanElement | null>(null);

  const [isTouchDevice, setIsTouchDevice] = useState(false);
  const [cursorActive, setCursorActive] = useState(false);

  useEffect(() => {
    // Check if device is touch-based or coarse pointer
    const checkTouch = () => {
      return (
        'ontouchstart' in window ||
        navigator.maxTouchPoints > 0 ||
        window.matchMedia('(pointer: coarse)').matches
      );
    };

    if (checkTouch()) {
      setIsTouchDevice(true);
      return;
    }

    setCursorActive(true);
    document.body.classList.add('custom-cursor-active');

    let mouseX = -100;
    let mouseY = -100;
    let outerX = -100;
    let outerY = -100;
    let isVisible = false;
    let rafId: number;

    const onMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      if (!isVisible) {
        isVisible = true;
        if (outerRef.current) outerRef.current.style.opacity = '1';
        if (dotRef.current) dotRef.current.style.opacity = '1';
      }

      // Check hovered element
      const target = e.target as HTMLElement | null;
      if (!target || !outerRef.current || !dotRef.current || !textRef.current) return;

      const cursorEl = target.closest('[data-cursor]') as HTMLElement | null;
      if (cursorEl) {
        const val = cursorEl.getAttribute('data-cursor');
        if (val === 'view') {
          outerRef.current.style.width = '68px';
          outerRef.current.style.height = '68px';
          outerRef.current.style.backgroundColor = 'rgba(212, 175, 87, 0.9)';
          outerRef.current.style.borderColor = 'rgba(240, 217, 149, 0.9)';
          dotRef.current.style.opacity = '0';
          textRef.current.textContent = 'VIEW';
          textRef.current.style.opacity = '1';
        } else if (val === 'play') {
          outerRef.current.style.width = '68px';
          outerRef.current.style.height = '68px';
          outerRef.current.style.backgroundColor = 'rgba(212, 175, 87, 0.9)';
          outerRef.current.style.borderColor = 'rgba(240, 217, 149, 0.9)';
          dotRef.current.style.opacity = '0';
          textRef.current.textContent = 'PLAY';
          textRef.current.style.opacity = '1';
        } else {
          outerRef.current.style.width = '44px';
          outerRef.current.style.height = '44px';
          outerRef.current.style.backgroundColor = 'rgba(212, 175, 87, 0.15)';
          outerRef.current.style.borderColor = 'rgba(212, 175, 87, 0.7)';
          dotRef.current.style.opacity = '1';
          textRef.current.textContent = '';
          textRef.current.style.opacity = '0';
        }
      } else if (target.closest('button, a, input, select, textarea, [role="button"]')) {
        outerRef.current.style.width = '42px';
        outerRef.current.style.height = '42px';
        outerRef.current.style.backgroundColor = 'rgba(212, 175, 87, 0.12)';
        outerRef.current.style.borderColor = 'rgba(212, 175, 87, 0.65)';
        dotRef.current.style.opacity = '1';
        textRef.current.textContent = '';
        textRef.current.style.opacity = '0';
      } else {
        outerRef.current.style.width = '28px';
        outerRef.current.style.height = '28px';
        outerRef.current.style.backgroundColor = 'transparent';
        outerRef.current.style.borderColor = 'rgba(212, 175, 87, 0.6)';
        dotRef.current.style.opacity = '1';
        textRef.current.textContent = '';
        textRef.current.style.opacity = '0';
      }
    };

    const onMouseLeave = () => {
      isVisible = false;
      if (outerRef.current) outerRef.current.style.opacity = '0';
      if (dotRef.current) dotRef.current.style.opacity = '0';
    };

    const renderLoop = () => {
      // Lerp outer cursor follower
      const ease = 0.2;
      outerX += (mouseX - outerX) * ease;
      outerY += (mouseY - outerY) * ease;

      if (outerRef.current) {
        outerRef.current.style.transform = `translate3d(${outerX}px, ${outerY}px, 0) translate(-50%, -50%)`;
      }
      if (dotRef.current) {
        dotRef.current.style.transform = `translate3d(${mouseX}px, ${mouseY}px, 0) translate(-50%, -50%)`;
      }

      rafId = requestAnimationFrame(renderLoop);
    };

    window.addEventListener('mousemove', onMouseMove, { passive: true });
    document.addEventListener('mouseleave', onMouseLeave);
    rafId = requestAnimationFrame(renderLoop);

    return () => {
      cancelAnimationFrame(rafId);
      document.body.classList.remove('custom-cursor-active');
      window.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseleave', onMouseLeave);
    };
  }, []);

  if (isTouchDevice || !cursorActive) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-[100] overflow-hidden">
      {/* Outer Follower Disc */}
      <div
        ref={outerRef}
        className="fixed top-0 left-0 w-7 h-7 rounded-full flex items-center justify-center pointer-events-none border border-[#D4AF57]/60 opacity-0 transition-[width,height,background-color,border-color] duration-200 shadow-[0_0_15px_rgba(212,175,87,0.2)]"
        style={{ willChange: 'transform' }}
      >
        <span
          ref={textRef}
          className="font-['Cinzel'] text-[10px] font-black tracking-widest text-[#080B10] opacity-0 select-none"
        />
      </div>

      {/* Central High Precision Dot */}
      <div
        ref={dotRef}
        className="fixed top-0 left-0 w-1.5 h-1.5 bg-[#F0D995] rounded-full pointer-events-none opacity-0 shadow-[0_0_6px_rgba(240,217,149,0.9)]"
        style={{ willChange: 'transform' }}
      />
    </div>
  );
};
