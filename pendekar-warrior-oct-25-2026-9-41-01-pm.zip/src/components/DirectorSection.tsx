/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Award,
  ExternalLink,
  Film,
  Sparkles,
  Clapperboard,
  ShieldCheck,
  CheckCircle2,
  Maximize2,
} from 'lucide-react';
import { JOHN_RADEL_BIO, DIRECTOR_FILMS, DirectorFilm } from '../data/directorData';
import { DirectorModal } from './DirectorModal';
import { triggerHaptic } from '../utils/haptics';
import { InteractiveButton } from './InteractiveButton';

export const DirectorSection: React.FC = () => {
  const [selectedFilm, setSelectedFilm] = useState<DirectorFilm | null>(null);
  const [filter, setFilter] = useState<'all' | 'iko' | 'award' | 'action'>('all');

  const filteredFilms = DIRECTOR_FILMS.filter((film) => {
    if (filter === 'all') return true;
    if (filter === 'iko') return film.category === 'iko' || film.cast.some((c) => c.includes('Iko Uwais'));
    if (filter === 'award') return film.category === 'award' || !!film.awards;
    if (filter === 'action') return film.category === 'action' || film.tag.toLowerCase().includes('action');
    return true;
  });

  return (
    <section className="py-24 px-6 md:px-10 bg-[#080B10] border-t border-[#1F2633] relative" id="director">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-14">
          <div className="inline-flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-[#D4AF57]" />
            <span className="font-['Cinzel'] text-xs uppercase tracking-[0.28em] text-[#D4AF57] font-bold">
              The Filmmaker &amp; Producer
            </span>
          </div>
          <h2 className="font-['Cinzel'] text-3xl sm:text-5xl text-[#F3F0E8] uppercase tracking-wider font-black">
            John Radel, ACS
          </h2>
          <p className="font-['Cinzel'] text-sm sm:text-base text-[#F0D995] tracking-[0.2em] uppercase font-bold mt-2">
            CEO • Producer • Cinematographer
          </p>
        </div>

        {/* Two Column Layout: Profile & Accreditations (Left) + Bio & Filmography (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
          {/* Left Column: Portrait & Prestigious Industry Accolades */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            {/* Visual Portrait Card */}
            <div className="relative rounded-xs overflow-hidden border border-[#D4AF57]/40 bg-[#111620] shadow-[0_16px_50px_rgba(0,0,0,0.8)] group">
              <div className="relative aspect-[4/5] overflow-hidden bg-[#080B10]">
                {/* Framed portrait of John Radel */}
                <img
                  src={JOHN_RADEL_BIO.profileImg}
                  alt="John Radel, ACS - Award-Winning Cinematographer and Producer"
                  className="w-full h-full object-cover filter contrast-110 brightness-95 group-hover:scale-103 transition-transform duration-700"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#080B10] via-[#080B10]/30 to-transparent pointer-events-none" />

                {/* Bottom Card Title Lockup */}
                <div className="absolute bottom-4 left-5 right-5 z-10">
                  <span className="text-[10px] font-['Cinzel'] uppercase tracking-[0.25em] text-[#D4AF57] font-bold block mb-0.5">
                    Australian Cinematographers Society
                  </span>
                  <h3 className="font-['Cinzel'] text-2xl font-black uppercase tracking-wider text-[#F3F0E8]">
                    JOHN RADEL, ACS
                  </h3>
                  <span className="text-xs uppercase font-['Cinzel'] font-bold text-[#F0D995] tracking-widest block mt-0.5">
                    CEO • Producer • Cinematographer
                  </span>
                </div>
              </div>

              {/* Quick Links & IMDb */}
              <div className="p-4 bg-[#111620] border-t border-white/5 flex items-center justify-between">
                <a
                  href={JOHN_RADEL_BIO.imdbUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => triggerHaptic('light')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xs bg-[#f5c518] hover:bg-[#e2b616] text-[#000000] font-sans font-black text-xs transition-colors"
                >
                  <span>IMDb Profile</span>
                  <ExternalLink className="w-3 h-3 stroke-[2.5]" />
                </a>

                <div className="flex items-center gap-1 text-[11px] font-['Cinzel'] uppercase text-[#D4AF57] tracking-wider">
                  <Award className="w-3.5 h-3.5" />
                  <span>35+ Awards</span>
                </div>
              </div>
            </div>

            {/* Accreditations Summary */}
            <div className="p-5 rounded-xs bg-[#111620] border border-white/10 space-y-3">
              <div className="flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-[#D4AF57] shrink-0 mt-0.5" />
                <div className="text-xs">
                  <strong className="text-[#F3F0E8] font-['Cinzel'] uppercase tracking-wider block">
                    Accreditation &amp; Guild
                  </strong>
                  <span className="text-[#9DA6B5]">Australian Cinematographers Society (ACS)</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Award className="w-4 h-4 text-[#D4AF57] shrink-0 mt-0.5" />
                <div className="text-xs">
                  <strong className="text-[#F3F0E8] font-['Cinzel'] uppercase tracking-wider block">
                    Master Mentorship
                  </strong>
                  <span className="text-[#9DA6B5]">
                    Studied in Budapest under Vilmos Zsigmond ASC HSC and László Kovács ASC HSC
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-[#D4AF57] shrink-0 mt-0.5" />
                <div className="text-xs">
                  <strong className="text-[#F3F0E8] font-['Cinzel'] uppercase tracking-wider block">
                    Asian Academy Awards
                  </strong>
                  <span className="text-[#9DA6B5]">
                    Winner: Best Cinematography for <em>Operandi Gerhana</em> (Netflix) &amp; <em>Dance of the Dragon</em>
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Narrative Biography & Interactive Filmography Poster Grid */}
          <div className="lg:col-span-7 flex flex-col gap-8">
            {/* Biography Prose */}
            <div className="flex flex-col gap-4 text-sm sm:text-base text-[#9DA6B5] font-['Be_Vietnam_Pro'] leading-relaxed">
              {JOHN_RADEL_BIO.bioParagraphs.map((para, idx) => (
                <p key={idx} className={idx === 0 ? 'text-[#F3F0E8] font-medium' : ''}>
                  {para}
                </p>
              ))}
            </div>

            {/* Filmography Section Header */}
            <div className="pt-6 border-t border-white/10">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5">
                <div>
                  <span className="font-['Cinzel'] text-xs uppercase tracking-[0.25em] text-[#D4AF57] font-bold block mb-1">
                    Featured Filmography
                  </span>
                  <h3 className="font-['Cinzel'] text-xl sm:text-2xl uppercase tracking-wider text-[#F3F0E8] font-bold">
                    Films &amp; Productions by John Radel
                  </h3>
                  <p className="text-xs text-[#9DA6B5] mt-1 font-['Be_Vietnam_Pro']">
                    Click any film poster below to inspect full production details, cast, and awards.
                  </p>
                </div>

                {/* Filter Controls (Clean Segmented Tabs) */}
                <div className="flex items-center gap-1 p-1 bg-[#111620] border border-white/10 rounded-xs shrink-0 self-start sm:self-auto overflow-x-auto max-w-full">
                  {[
                    { id: 'all', label: 'All' },
                    { id: 'iko', label: 'Iko Uwais' },
                    { id: 'award', label: 'Awards' },
                    { id: 'action', label: 'Action/Sci-Fi' },
                  ].map((t) => (
                    <button
                      key={t.id}
                      onClick={() => {
                        triggerHaptic('selection');
                        setFilter(t.id as typeof filter);
                      }}
                      className={`px-3 py-1 text-[11px] font-['Cinzel'] uppercase tracking-wider rounded-xs transition-colors cursor-pointer whitespace-nowrap ${
                        filter === t.id
                          ? 'bg-[#D4AF57] text-[#080B10] font-bold shadow-sm'
                          : 'text-[#9DA6B5] hover:text-[#F3F0E8]'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Film Posters Grid (Clickable Cards with Authentic Poster Artwork & ThoughtLab Hover) */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5 sm:gap-4">
                {filteredFilms.map((film) => (
                  <motion.div
                    key={film.id}
                    whileHover={{ scale: 1.03, y: -4 }}
                    whileTap={{ scale: 0.96 }}
                    transition={{ type: 'spring', stiffness: 400, damping: 25 }}
                    onClick={() => {
                      triggerHaptic('medium');
                      setSelectedFilm(film);
                    }}
                    data-cursor="view"
                    className="group relative aspect-[2/3] rounded-xs overflow-hidden border border-white/10 hover:border-[#D4AF57] bg-[#080B10] cursor-pointer shadow-lg flex flex-col justify-between p-3 sm:p-3.5 transition-all duration-300"
                  >
                    {/* Underlying Stylized Background Gradient */}
                    <div className={`absolute inset-0 bg-gradient-to-b ${film.posterBg} opacity-90`} />

                    {/* Authentic Theatrical Film Poster Image */}
                    <img
                      src={film.posterImg}
                      alt={`${film.title} Poster`}
                      className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                      onError={(e) => {
                        // Fallback to background gradient if image fails to load
                        (e.currentTarget as HTMLElement).style.display = 'none';
                      }}
                    />

                    {/* Atmospheric Cinematic Lighting Overlays */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#080B10] via-[#080B10]/40 to-black/30 group-hover:from-[#080B10]/95 group-hover:via-[#080B10]/50 transition-colors pointer-events-none" />
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-white/10 via-transparent to-black/50 pointer-events-none" />

                    {/* Top: Year & Tag */}
                    <div className="relative z-10 flex items-center justify-between text-[10px] font-['Cinzel']">
                      <span className="text-[#F0D995] font-bold px-1.5 py-0.5 rounded-xs bg-[#080B10]/80 backdrop-blur-xs border border-white/10">
                        {film.year}
                      </span>
                      <span className="px-1.5 py-0.5 rounded-xs bg-[#080B10]/85 text-[#D4AF57] border border-white/10 text-[9px] uppercase tracking-wider backdrop-blur-xs">
                        {film.tag}
                      </span>
                    </div>

                    {/* Center: Hover Trigger Icon */}
                    <div className="relative z-10 flex items-center justify-center">
                      <div className="w-10 h-10 rounded-full bg-[#080B10]/80 backdrop-blur-sm border border-[#D4AF57] text-[#F0D995] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 transform scale-75 group-hover:scale-100 shadow-[0_0_15px_rgba(212,175,87,0.4)]">
                        <Maximize2 className="w-4 h-4" />
                      </div>
                    </div>

                    {/* Bottom: Title & Role */}
                    <div className="relative z-10 bg-[#080B10]/75 backdrop-blur-xs -mx-1.5 -mb-1.5 p-2 rounded-xs border-t border-white/5">
                      <h4 className="font-['Cinzel'] text-xs sm:text-sm font-black uppercase text-[#F3F0E8] tracking-wider leading-snug group-hover:text-[#F0D995] transition-colors truncate">
                        {film.title}
                      </h4>
                      <p className="text-[9px] sm:text-[10px] font-['Cinzel'] uppercase tracking-wider text-[#D4AF57] font-semibold mt-0.5 truncate">
                        {film.role}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Film Detail Modal Popup */}
      <DirectorModal
        film={selectedFilm}
        onClose={() => setSelectedFilm(null)}
      />
    </section>
  );
};
