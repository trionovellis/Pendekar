/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Wifi, WifiOff, RefreshCw, CheckCircle2, Clock, AlertTriangle, X } from 'lucide-react';
import {
  getSyncQueue,
  getPendingSyncCount,
  processSyncQueue,
  subscribeToSyncChanges,
  clearSyncQueue,
  SyncAction,
} from '../utils/syncManager';
import { triggerHaptic } from '../utils/haptics';
import { InteractiveButton } from './InteractiveButton';

export const OfflineSyncHub: React.FC = () => {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [isSimulatedOffline, setIsSimulatedOffline] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);
  const [queue, setQueue] = useState<SyncAction[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);
  const [showDrawer, setShowDrawer] = useState(false);
  const [lastSyncMessage, setLastSyncMessage] = useState<string | null>(null);

  const effectiveOnline = isOnline && !isSimulatedOffline;

  // Refresh local state from syncManager
  const refreshState = () => {
    setPendingCount(getPendingSyncCount());
    setQueue(getSyncQueue());
  };

  useEffect(() => {
    refreshState();
    const unsubscribe = subscribeToSyncChanges(() => {
      refreshState();
    });

    const handleOnline = async () => {
      setIsOnline(true);
      triggerHaptic('success');
      // Background auto-sync on reconnect!
      if (getPendingSyncCount() > 0) {
        setIsSyncing(true);
        const res = await processSyncQueue(900);
        setIsSyncing(false);
        setLastSyncMessage(`Background synced ${res.processed} item${res.processed > 1 ? 's' : ''}`);
        setTimeout(() => setLastSyncMessage(null), 4000);
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      triggerHaptic('heavy');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      unsubscribe();
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleManualSync = async () => {
    if (!effectiveOnline) {
      triggerHaptic('heavy');
      return;
    }
    triggerHaptic('medium');
    setIsSyncing(true);
    const res = await processSyncQueue(800);
    setIsSyncing(false);
    triggerHaptic('success');
    setLastSyncMessage(`Synced ${res.processed} action${res.processed > 1 ? 's' : ''} to film servers.`);
    setTimeout(() => setLastSyncMessage(null), 4000);
  };

  const toggleSimulateOffline = () => {
    triggerHaptic('medium');
    const nextState = !isSimulatedOffline;
    setIsSimulatedOffline(nextState);
    if (!nextState && pendingCount > 0) {
      // Reconnected from simulation -> trigger background sync
      handleManualSync();
    }
  };

  return (
    <>
      {/* Floating Status Pill (Bottom Left) */}
      <div className="fixed bottom-5 left-5 z-40 flex flex-col items-start gap-2">
        {/* Offline / Queued Badge */}
        {(!effectiveOnline || pendingCount > 0 || lastSyncMessage) && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 15 }}
            className={`flex items-center gap-3 px-3.5 py-2 rounded-xs border text-xs font-['Cinzel'] tracking-wider shadow-xl backdrop-blur-xl ${
              !effectiveOnline
                ? 'bg-[#111620]/95 border-amber-500/50 text-amber-300'
                : pendingCount > 0
                ? 'bg-[#111620]/95 border-[#D4AF57]/60 text-[#F0D995]'
                : 'bg-[#111620]/95 border-emerald-500/50 text-emerald-300'
            }`}
          >
            <div className="flex items-center gap-2">
              {!effectiveOnline ? (
                <WifiOff className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              ) : isSyncing ? (
                <RefreshCw className="w-3.5 h-3.5 text-[#D4AF57] animate-spin" />
              ) : pendingCount > 0 ? (
                <Clock className="w-3.5 h-3.5 text-[#D4AF57]" />
              ) : (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              )}

              <span>
                {!effectiveOnline
                  ? 'Offline Mode'
                  : isSyncing
                  ? 'Syncing In Background...'
                  : lastSyncMessage
                  ? lastSyncMessage
                  : `${pendingCount} Queued For Sync`}
              </span>
            </div>

            <button
              onClick={() => {
                triggerHaptic('light');
                setShowDrawer(true);
              }}
              className="text-[10px] uppercase font-bold text-[#F3F0E8] hover:text-[#D4AF57] underline ml-1 cursor-pointer"
            >
              Inspect
            </button>
          </motion.div>
        )}
      </div>

      {/* Sync Queue Inspection Modal / Drawer */}
      <AnimatePresence>
        {showDrawer && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#080B10]/85 backdrop-blur-xl">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative w-full max-w-lg bg-[#111620] border border-[#D4AF57]/40 rounded-xs shadow-2xl p-6 overflow-hidden"
            >
              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-white/10">
                <div className="flex items-center gap-2.5">
                  <RefreshCw className={`w-5 h-5 ${isSyncing ? 'animate-spin text-[#D4AF57]' : 'text-[#F0D995]'}`} />
                  <div>
                    <h3 className="font-['Cinzel'] text-base uppercase font-bold text-[#F3F0E8] tracking-wider">
                      Offline Sync Hub
                    </h3>
                    <p className="text-[11px] text-[#9DA6B5]">
                      Background sync engine for reservations, dossiers, and queries
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    triggerHaptic('light');
                    setShowDrawer(false);
                  }}
                  className="p-1 text-[#9DA6B5] hover:text-[#F3F0E8] transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Network Status Banner */}
              <div className="my-4 p-3 rounded-xs bg-[#080B10] border border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs">
                  {effectiveOnline ? (
                    <>
                      <Wifi className="w-4 h-4 text-emerald-400" />
                      <span className="text-[#F3F0E8]">Online & Ready to Synchronize</span>
                    </>
                  ) : (
                    <>
                      <WifiOff className="w-4 h-4 text-amber-400 animate-pulse" />
                      <span className="text-amber-300">Offline (Local Cache Active)</span>
                    </>
                  )}
                </div>

                {/* Simulation toggle */}
                <button
                  onClick={toggleSimulateOffline}
                  className={`text-[10px] uppercase font-['Cinzel'] font-bold px-2.5 py-1 rounded-xs border transition-colors cursor-pointer ${
                    isSimulatedOffline
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                      : 'bg-white/5 text-[#9DA6B5] hover:text-[#F3F0E8] border-white/10'
                  }`}
                >
                  {isSimulatedOffline ? 'Resume Online' : 'Simulate Offline'}
                </button>
              </div>

              {/* Queue List */}
              <div className="mb-5">
                <div className="flex items-center justify-between text-xs font-['Cinzel'] text-[#9DA6B5] mb-2 uppercase tracking-wider">
                  <span>Queued Actions ({queue.length})</span>
                  {queue.length > 0 && (
                    <button
                      onClick={() => {
                        triggerHaptic('light');
                        clearSyncQueue();
                      }}
                      className="text-[10px] text-red-400 hover:text-red-300 cursor-pointer"
                    >
                      Clear History
                    </button>
                  )}
                </div>

                <div className="max-h-60 overflow-y-auto space-y-2 pr-1 custom-scroll">
                  {queue.length === 0 ? (
                    <div className="text-center py-8 text-xs text-[#9DA6B5]">
                      No pending sync actions. Every reservation and interaction is up to date!
                    </div>
                  ) : (
                    queue.map((item) => (
                      <div
                        key={item.id}
                        className="p-3 bg-[#080B10]/70 border border-white/5 rounded-xs flex items-center justify-between gap-3 text-xs"
                      >
                        <div className="flex flex-col">
                          <span className="font-['Cinzel'] text-xs font-bold uppercase text-[#F0D995]">
                            {item.type === 'rsvp'
                              ? 'VIP Screener RSVP'
                              : item.type === 'bookmark'
                              ? 'Character Dossier Save'
                              : item.type === 'inquiry'
                              ? 'Distribution Inquiry'
                              : 'Interaction'}
                          </span>
                          <span className="text-[11px] text-[#9DA6B5] truncate max-w-[280px]">
                            {item.payload.name
                              ? String(item.payload.name)
                              : item.payload.title
                              ? String(item.payload.title)
                              : item.payload.email
                              ? String(item.payload.email)
                              : JSON.stringify(item.payload)}
                          </span>
                        </div>

                        <div className="shrink-0 flex items-center gap-1.5 text-[11px]">
                          {item.status === 'synced' ? (
                            <span className="text-emerald-400 flex items-center gap-1 font-['Cinzel'] text-[10px] uppercase">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Synced
                            </span>
                          ) : item.status === 'syncing' ? (
                            <span className="text-[#D4AF57] flex items-center gap-1 font-['Cinzel'] text-[10px] uppercase">
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Syncing
                            </span>
                          ) : (
                            <span className="text-amber-400 flex items-center gap-1 font-['Cinzel'] text-[10px] uppercase">
                              <Clock className="w-3.5 h-3.5" /> Pending
                            </span>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Actions Footer */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <InteractiveButton
                  variant="subtle"
                  onClick={() => setShowDrawer(false)}
                >
                  Close
                </InteractiveButton>
                <InteractiveButton
                  variant="gold"
                  disabled={!effectiveOnline || pendingCount === 0 || isSyncing}
                  onClick={handleManualSync}
                  className={pendingCount === 0 || !effectiveOnline ? 'opacity-50 cursor-not-allowed' : ''}
                >
                  {isSyncing ? 'Syncing...' : 'Sync Queue Now'}
                </InteractiveButton>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
