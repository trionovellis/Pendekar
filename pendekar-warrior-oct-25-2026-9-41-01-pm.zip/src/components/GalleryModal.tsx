/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ChevronLeft, ChevronRight, Bookmark, BookmarkCheck } from 'lucide-react';
import { ProductionStill } from '../data/filmData';
import { toggleStoredBookmark, getStoredBookmarks } from '../utils/syncManager';
import { triggerHaptic } from '../utils/haptics';

interface GalleryModalProps {
  still: ProductionStill | null;
  allStills: ProductionStill[];
  onClose: () => void;
  onSelectStill: (still: ProductionStill) => void;
}

export const GalleryModal: React.FC<GalleryModalProps> = ({
  still,
  allStills,
  onClose,
  onSelectStill,
}) => {
  const [bookmarks, setBookmarks] = React.useState<string[]>([]);

  useEffect(() => {
    setBookmarks(getStoredBookmarks());
  }, []);

  useEffect(() => {
    if (!still) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [still, allStills]);

  if (!still) return null;

  const currentIndex = allStills.findIndex((item) => item.id === still.id);

  const handleNext = () => {
    triggerHaptic('light');
    const nextIdx = (currentIndex + 1) % allStills.length;
    onSelectStill(allStills[nextIdx]);
  };

  const handlePrev = () => {
    triggerHaptic('light');
    const prevIdx = (currentIndex - 1 + allStills.length) % allStills.length;
    onSelectStill(allStills[prevIdx]);
  };

  const isBookmarked = bookmarks.includes(still.id);

  const handleToggleBookmark = () => {
    triggerHaptic('medium');
    const res = toggleStoredBookmark(still.id);
    setBookmarks(res.list);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#080B10]/95 backdrop-blur-2xl">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-5xl flex flex-col"
        >
          {/* Header Bar */}
          <div className="flex items-center justify-between pb-3 text-xs font-['Cinzel']">
            <span className="text-[#D4AF57] uppercase tracking-[0.2em]">
              Production Still {currentIndex + 1} of {allStills.length}
            </span>
            <div className="flex items-center gap-3">
              <button
                onClick={handleToggleBookmark}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xs border border-white/10 hover:border-[#D4AF57]/60 text-[#F3F0E8] hover:text-[#F0D995] transition-colors cursor-pointer"
              >
                {isBookmarked ? (
                  <>
                    <BookmarkCheck className="w-4 h-4 text-[#D4AF57]" />
                    <span className="text-[11px]">Saved in Archive</span>
                  </>
                ) : (
                  <>
                    <Bookmark className="w-4 h-4 text-[#9DA6B5]" />
                    <span className="text-[11px]">Save Still</span>
                  </>
                )}
              </button>
              <button
                onClick={() => {
                  triggerHaptic('light');
                  onClose();
                }}
                aria-label="Close Lightbox"
                className="p-1.5 text-[#9DA6B5] hover:text-[#F3F0E8] transition-colors cursor-pointer"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Main Stage */}
          <div className="relative bg-[#111620] border border-white/10 rounded-xs overflow-hidden shadow-2xl">
            <div className="relative aspect-[16/9] w-full bg-[#080B10] flex items-center justify-center">
              <img
                src={still.img}
                alt={still.title}
                className="w-full h-full object-contain"
                loading="eager"
              />

              {/* Arrow navigation */}
              <button
                onClick={handlePrev}
                aria-label="Previous Still"
                className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-[#080B10]/70 border border-white/10 text-[#F3F0E8] hover:text-[#D4AF57] hover:scale-110 transition-all cursor-pointer backdrop-blur-sm"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                onClick={handleNext}
                aria-label="Next Still"
                className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-[#080B10]/70 border border-white/10 text-[#F3F0E8] hover:text-[#D4AF57] hover:scale-110 transition-all cursor-pointer backdrop-blur-sm"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>

            {/* Caption Strip */}
            <div className="p-4 sm:p-6 bg-[#111620] flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-white/5">
              <div>
                <h4 className="font-['Cinzel'] text-base uppercase tracking-wider text-[#F3F0E8] font-bold">
                  {still.title}
                </h4>
                <p className="font-['Be_Vietnam_Pro'] text-xs text-[#9DA6B5] mt-1 leading-relaxed">
                  {still.caption}
                </p>
              </div>
              <div className="text-right shrink-0">
                <span className="text-[11px] font-['Cinzel'] uppercase tracking-[0.2em] text-[#D4AF57] block">
                  {still.location}
                </span>
                <span className="text-[10px] text-[#9DA6B5]/70 font-['Cinzel'] uppercase tracking-widest">
                  Category: {still.category}
                </span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
