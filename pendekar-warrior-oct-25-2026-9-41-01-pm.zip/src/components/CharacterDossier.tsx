/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bookmark, BookmarkCheck, Shield, Sparkles, UserCheck } from 'lucide-react';
import { CHARACTERS, Character } from '../data/filmData';
import { LazyImage } from './LazyImage';
import { triggerHaptic } from '../utils/haptics';
import { toggleStoredBookmark, getStoredBookmarks } from '../utils/syncManager';
import { InteractiveButton } from './InteractiveButton';

export const CharacterDossier: React.FC = () => {
  const [activeCharId, setActiveCharId] = useState(CHARACTERS[0].id);
  const [bookmarks, setBookmarks] = useState<string[]>([]);

  useEffect(() => {
    setBookmarks(getStoredBookmarks());
  }, []);

  const activeChar = CHARACTERS.find((c) => c.id === activeCharId) || CHARACTERS[0];
  const isBookmarked = bookmarks.includes(activeChar.id);

  const handleToggleBookmark = () => {
    triggerHaptic('medium');
    const res = toggleStoredBookmark(activeChar.id);
    setBookmarks(res.list);
  };

  return (
    <section className="py-24 px-6 md:px-10 bg-[#080B10] border-t border-[#1F2633] relative" id="characters">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <span className="font-['Cinzel'] text-xs uppercase tracking-[0.28em] text-[#D4AF57] font-bold block mb-2">
            Character Dossiers
          </span>
          <h2 className="font-['Cinzel'] text-2xl sm:text-4xl text-[#F3F0E8] uppercase tracking-wider font-bold">
            The People Behind the Fight
          </h2>
          <p className="font-['Be_Vietnam_Pro'] text-sm sm:text-base text-[#9DA6B5] mt-2">
            Every battle has a history. Every choice has a consequence.
          </p>
        </div>

        {/* Character Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 custom-scroll">
          {CHARACTERS.map((char) => {
            const isActive = char.id === activeCharId;
            return (
              <button
                key={char.id}
                onClick={() => {
                  triggerHaptic('selection');
                  setActiveCharId(char.id);
                }}
                className={`relative px-5 py-2.5 rounded-xs border font-['Cinzel'] text-xs uppercase tracking-[0.18em] transition-all shrink-0 cursor-pointer ${
                  isActive
                    ? 'border-[#D4AF57] bg-[#D4AF57] text-[#080B10] font-bold shadow-[0_0_20px_rgba(212,175,87,0.3)]'
                    : 'border-white/10 bg-[#111620] text-[#9DA6B5] hover:text-[#F3F0E8] hover:border-[#D4AF57]/50 font-semibold'
                }`}
              >
                {char.name}
              </button>
            );
          })}
        </div>

        {/* Character Display Card */}
        <div className="bg-[#111620] border border-white/10 rounded-xs p-6 md:p-10 shadow-[0_16px_50px_rgba(0,0,0,0.6)]">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeChar.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center"
            >
              {/* Character Portrait */}
              <div className="lg:col-span-5 flex justify-center">
                <div
                  data-cursor="view"
                  className="relative w-full max-w-sm aspect-[3/4] rounded-xs overflow-hidden border border-white/10 shadow-2xl bg-[#080B10] group"
                >
                  <LazyImage
                    src={activeChar.img}
                    alt={`${activeChar.name} Character Portrait`}
                    aspectRatioClass="aspect-[3/4]"
                    zoomOnHover={true}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#080B10]/95 via-transparent to-transparent pointer-events-none" />

                  <div className="absolute bottom-4 left-4 right-4">
                    <span className="text-[11px] font-['Cinzel'] uppercase tracking-[0.2em] text-[#D4AF57] block">
                      {activeChar.role}
                    </span>
                    <h3 className="font-['Cinzel'] text-xl md:text-2xl uppercase tracking-wider text-[#F3F0E8] font-bold">
                      {activeChar.name}
                    </h3>
                  </div>
                </div>
              </div>

              {/* Character Profile Bio */}
              <div className="lg:col-span-7 flex flex-col gap-6">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <span className="font-['Cinzel'] text-xs uppercase tracking-[0.25em] text-[#F0D995] font-semibold block mb-1">
                      {activeChar.role}
                    </span>
                    <h3 className="font-['Cinzel'] text-2xl md:text-3xl font-bold uppercase text-[#F3F0E8] tracking-wide">
                      {activeChar.name}
                    </h3>
                  </div>

                  {/* Bookmark Button */}
                  <InteractiveButton
                    variant={isBookmarked ? 'gold' : 'glass'}
                    hapticType="medium"
                    onClick={handleToggleBookmark}
                    className="flex items-center gap-2 py-2 px-3.5 text-[11px]"
                  >
                    {isBookmarked ? (
                      <>
                        <BookmarkCheck className="w-3.5 h-3.5 text-[#080B10]" />
                        <span>Saved to Dossiers</span>
                      </>
                    ) : (
                      <>
                        <Bookmark className="w-3.5 h-3.5 text-[#D4AF57]" />
                        <span>Save Dossier</span>
                      </>
                    )}
                  </InteractiveButton>
                </div>

                <div className="h-px w-16 bg-[#D4AF57]/60" />

                <p className="font-['Be_Vietnam_Pro'] text-sm sm:text-base text-[#9DA6B5] leading-relaxed">
                  {activeChar.desc}
                </p>

                {/* Attributes Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div className="p-4 rounded-xs bg-[#080B10]/60 border border-white/5">
                    <span className="font-['Cinzel'] text-[11px] uppercase tracking-[0.2em] text-[#D4AF57] block mb-1">
                      Motivation
                    </span>
                    <p className="font-['Be_Vietnam_Pro'] text-xs sm:text-sm text-[#F3F0E8]">
                      {activeChar.motivation}
                    </p>
                  </div>

                  <div className="p-4 rounded-xs bg-[#080B10]/60 border border-white/5">
                    <span className="font-['Cinzel'] text-[11px] uppercase tracking-[0.2em] text-[#D4AF57] block mb-1">
                      Moral Conflict
                    </span>
                    <p className="font-['Be_Vietnam_Pro'] text-xs sm:text-sm text-[#F3F0E8]">
                      {activeChar.conflict}
                    </p>
                  </div>

                  <div className="p-4 rounded-xs bg-[#080B10]/60 border border-white/5 sm:col-span-2">
                    <span className="font-['Cinzel'] text-[11px] uppercase tracking-[0.2em] text-[#F0D995] block mb-1">
                      Combat Archetype & Style
                    </span>
                    <p className="font-['Be_Vietnam_Pro'] text-xs sm:text-sm text-[#9DA6B5]">
                      {activeChar.style}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
};
