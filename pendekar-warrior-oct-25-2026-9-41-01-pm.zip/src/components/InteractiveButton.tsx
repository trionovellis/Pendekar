/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion, HTMLMotionProps } from 'motion/react';
import { triggerHaptic, HapticType } from '../utils/haptics';

interface InteractiveButtonProps extends HTMLMotionProps<'button'> {
  variant?: 'gold' | 'glass' | 'outline' | 'subtle' | 'ghost';
  hapticType?: HapticType;
  children: React.ReactNode;
  cursorLabel?: string;
}

export const InteractiveButton: React.FC<InteractiveButtonProps> = ({
  variant = 'glass',
  hapticType = 'light',
  children,
  cursorLabel,
  className = '',
  onClick,
  ...props
}) => {
  const getVariantStyles = () => {
    switch (variant) {
      case 'gold':
        return 'bg-gradient-to-r from-[#D4AF57] to-[#F0D995] text-[#080B10] font-bold shadow-[0_0_25px_rgba(212,175,87,0.35)] hover:shadow-[0_0_35px_rgba(212,175,87,0.6)] border border-[#F0D995]/50';
      case 'outline':
        return 'border border-[#D4AF57]/60 text-[#F0D995] hover:text-[#080B10] hover:bg-[#D4AF57] shadow-[0_0_15px_rgba(212,175,87,0.15)] hover:shadow-[0_0_25px_rgba(212,175,87,0.4)]';
      case 'glass':
        return 'bg-[#111620]/80 border border-white/10 hover:border-[#D4AF57]/60 text-[#F3F0E8] hover:text-[#F0D995] backdrop-blur-md';
      case 'subtle':
        return 'bg-[#111620] border border-white/5 hover:border-white/20 text-[#9DA6B5] hover:text-[#F3F0E8]';
      case 'ghost':
        return 'text-[#9DA6B5] hover:text-[#D4AF57] bg-transparent';
    }
  };

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    triggerHaptic(hapticType);
    if (onClick) {
      onClick(e);
    }
  };

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.95 }}
      transition={{ type: 'spring', stiffness: 450, damping: 24 }}
      onClick={handleClick}
      data-cursor={cursorLabel || 'pointer'}
      className={`inline-flex items-center justify-center font-['Cinzel'] text-xs uppercase tracking-[0.18em] transition-colors duration-200 select-none cursor-pointer rounded-xs px-5 py-2.5 ${getVariantStyles()} ${className}`}
      {...props}
    >
      {children}
    </motion.button>
  );
};
