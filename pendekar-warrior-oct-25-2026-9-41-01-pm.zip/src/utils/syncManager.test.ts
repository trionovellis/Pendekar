import test from 'node:test';
import assert from 'node:assert/strict';

// Set up mock localStorage for node environment
const memoryStore = new Map<string, string>();
const mockLocalStorage = {
  getItem: (key: string) => memoryStore.get(key) || null,
  setItem: (key: string, value: string) => memoryStore.set(key, value),
  removeItem: (key: string) => memoryStore.delete(key),
  clear: () => memoryStore.clear(),
};

(globalThis as unknown as { window: { localStorage: typeof mockLocalStorage } }).window = {
  localStorage: mockLocalStorage,
};
(globalThis as unknown as { localStorage: typeof mockLocalStorage }).localStorage = mockLocalStorage;

import {
  queueSyncAction,
  getSyncQueue,
  getPendingSyncCount,
  processSyncQueue,
  clearSyncQueue,
  toggleStoredBookmark,
  getStoredBookmarks,
} from './syncManager';

test('offline sync queue queues items correctly', () => {
  clearSyncQueue();
  assert.equal(getPendingSyncCount(), 0);

  const action = queueSyncAction('rsvp', { name: 'Aris', email: 'aris@example.com' });
  assert.equal(action.type, 'rsvp');
  assert.equal(action.status, 'pending');
  assert.equal(getPendingSyncCount(), 1);

  const queue = getSyncQueue();
  assert.equal(queue.length, 1);
  assert.equal(queue[0].payload.name, 'Aris');
});

test('processSyncQueue transitions pending items to synced', async () => {
  clearSyncQueue();
  queueSyncAction('inquiry', { message: 'Festival screening distribution' });
  queueSyncAction('bookmark', { characterId: 'jaya' });

  assert.equal(getPendingSyncCount(), 2);

  const result = await processSyncQueue(0);
  assert.equal(result.processed, 2);
  assert.equal(getPendingSyncCount(), 0);

  const queue = getSyncQueue();
  assert.equal(queue[0].status, 'synced');
  assert.ok(queue[0].syncedAt);
});

test('toggleStoredBookmark adds and removes bookmarks', () => {
  mockLocalStorage.clear();
  const initial = getStoredBookmarks();
  assert.ok(Array.isArray(initial));

  const res1 = toggleStoredBookmark('character_kazu');
  assert.equal(res1.bookmarked, true);
  assert.ok(res1.list.includes('character_kazu'));

  const res2 = toggleStoredBookmark('character_kazu');
  assert.equal(res2.bookmarked, false);
  assert.ok(!res2.list.includes('character_kazu'));
});
