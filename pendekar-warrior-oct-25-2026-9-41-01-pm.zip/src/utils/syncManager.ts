/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface SyncAction {
  id: string;
  type: 'rsvp' | 'bookmark' | 'inquiry' | 'rating';
  payload: Record<string, unknown>;
  status: 'pending' | 'syncing' | 'synced' | 'failed';
  createdAt: number;
  syncedAt?: number;
  retryCount: number;
  error?: string;
}

const STORAGE_KEY = 'pendekar_offline_sync_queue_v1';
const BOOKMARKS_KEY = 'pendekar_bookmarked_items_v1';

export function getSyncQueue(): SyncAction[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveSyncQueue(queue: SyncAction[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(queue));
  } catch (err) {
    console.error('Failed to persist sync queue:', err);
  }
}

export function queueSyncAction(
  type: SyncAction['type'],
  payload: Record<string, unknown>
): SyncAction {
  const newAction: SyncAction = {
    id: 'sync_' + Math.random().toString(36).substring(2, 9) + '_' + Date.now(),
    type,
    payload,
    status: 'pending',
    createdAt: Date.now(),
    retryCount: 0,
  };

  const queue = getSyncQueue();
  queue.push(newAction);
  saveSyncQueue(queue);

  notifySyncListeners();
  return newAction;
}

export function getPendingSyncCount(): number {
  return getSyncQueue().filter((item) => item.status === 'pending').length;
}

export async function processSyncQueue(
  mockNetworkLatencyMs = 600
): Promise<{ processed: number; failed: number }> {
  const queue = getSyncQueue();
  const pendingIndices: number[] = [];

  queue.forEach((item, idx) => {
    if (item.status === 'pending' || item.status === 'failed') {
      pendingIndices.push(idx);
    }
  });

  if (pendingIndices.length === 0) {
    return { processed: 0, failed: 0 };
  }

  // Mark pending as syncing
  pendingIndices.forEach((idx) => {
    queue[idx].status = 'syncing';
  });
  saveSyncQueue(queue);
  notifySyncListeners();

  // Simulate server delivery
  if (mockNetworkLatencyMs > 0) {
    await new Promise((res) => setTimeout(res, mockNetworkLatencyMs));
  }

  let processed = 0;
  let failed = 0;

  pendingIndices.forEach((idx) => {
    // 100% success for valid payloads in our mock backend
    queue[idx].status = 'synced';
    queue[idx].syncedAt = Date.now();
    processed++;
  });

  saveSyncQueue(queue);
  notifySyncListeners();
  return { processed, failed };
}

export function clearSyncQueue(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(STORAGE_KEY);
  notifySyncListeners();
}

// Bookmarks helper (offline persistent)
export function getStoredBookmarks(): string[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(BOOKMARKS_KEY);
    return raw ? JSON.parse(raw) : ['jaya', 'cipinang'];
  } catch {
    return ['jaya', 'cipinang'];
  }
}

export function toggleStoredBookmark(id: string): { bookmarked: boolean; list: string[] } {
  const list = getStoredBookmarks();
  const exists = list.includes(id);
  const updated = exists ? list.filter((item) => item !== id) : [...list, id];
  try {
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to store bookmark:', err);
  }
  return { bookmarked: !exists, list: updated };
}

// Listener subscription system for instant UI updates across components
type SyncListener = () => void;
const listeners = new Set<SyncListener>();

export function subscribeToSyncChanges(callback: SyncListener): () => void {
  listeners.add(callback);
  return () => {
    listeners.delete(callback);
  };
}

function notifySyncListeners() {
  listeners.forEach((listener) => {
    try {
      listener();
    } catch (e) {
      console.error(e);
    }
  });
}
