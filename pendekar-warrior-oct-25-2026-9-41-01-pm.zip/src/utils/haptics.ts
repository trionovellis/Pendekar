/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Tactile Haptic Engine with Web Vibration & Audio Impulse Synthesizer
let audioCtx: AudioContext | null = null;
let hapticsEnabled = true;

const HAPTICS_PREF_KEY = 'pendekar_haptics_enabled';

// Initialize preference
if (typeof window !== 'undefined') {
  try {
    const saved = localStorage.getItem(HAPTICS_PREF_KEY);
    if (saved !== null) {
      hapticsEnabled = saved === 'true';
    }
  } catch {
    // ignore
  }
}

export function isHapticsEnabled(): boolean {
  return hapticsEnabled;
}

export function setHapticsEnabled(enabled: boolean): void {
  hapticsEnabled = enabled;
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(HAPTICS_PREF_KEY, String(enabled));
    } catch {
      // ignore
    }
  }
}

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass =
      window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

export type HapticType = 'light' | 'medium' | 'heavy' | 'success' | 'selection';

/**
 * Triggers both device physical vibration (if supported) and an ultra-short,
 * velvety acoustic impulse synthesized via Web Audio API.
 */
export function triggerHaptic(type: HapticType = 'light'): void {
  if (!hapticsEnabled || typeof window === 'undefined') return;

  // 1. Device Vibration API (Android / PWA devices)
  try {
    if (navigator.vibrate) {
      switch (type) {
        case 'light':
        case 'selection':
          navigator.vibrate(8);
          break;
        case 'medium':
          navigator.vibrate(16);
          break;
        case 'heavy':
          navigator.vibrate(28);
          break;
        case 'success':
          navigator.vibrate([10, 30, 20]);
          break;
      }
    }
  } catch {
    // Vibration ignored
  }

  // 2. Web Audio Micro-Impulse Synthesizer (Desktop + iOS + All Browsers)
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    const now = ctx.currentTime;

    // Subtle low-frequency tactile mechanical tick parameters
    let freq = 140;
    let duration = 0.012; // 12ms
    let targetGain = 0.08;

    switch (type) {
      case 'selection':
      case 'light':
        freq = 150;
        duration = 0.009;
        targetGain = 0.05;
        break;
      case 'medium':
        freq = 120;
        duration = 0.015;
        targetGain = 0.08;
        break;
      case 'heavy':
        freq = 90;
        duration = 0.022;
        targetGain = 0.12;
        break;
      case 'success':
        freq = 240;
        duration = 0.035;
        targetGain = 0.09;
        break;
    }

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, now);
    osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq * 0.4), now + duration);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(800, now);

    gain.gain.setValueAtTime(targetGain, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + duration);
  } catch {
    // Audio synthesis fallback
  }
}
